if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface SideBarPage_Params {
}
class SideBarPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: SideBarPage_Params) {
    }
    updateStateVars(params: SideBarPage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            SideBarContainer.create(SideBarContainerType.Embed);
            SideBarContainer.debugLine("entry/src/main/ets/pages/SideBarPage.ets(6:5)", "entry");
            SideBarContainer.showSideBar(false);
            SideBarContainer.sideBarWidth(100);
            SideBarContainer.minSideBarWidth(100);
            SideBarContainer.maxSideBarWidth(150);
            SideBarContainer.controlButton({
                width: 30,
                height: 30,
                top: 15, // 设置侧边栏控制按钮距离容器顶部为15
                // icons: {                                       // 设置侧边栏控制按钮图片
                //   shown: $r("app.media.icon_back"),            // 设置侧边栏显示时控制按钮的图标。
                //   hidden: $r("app.media.icon_menu"),           // 设置侧边栏隐藏时控制按钮的图标。
                //   switching: $r("app.media.icon_back")         // 设置侧边栏显示和隐藏状态切换时控制按钮的图标。
                // }
            });
            SideBarContainer.width('100%');
            SideBarContainer.height('100%');
        }, SideBarContainer);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/SideBarPage.ets(7:7)", "entry");
            Column.width(10);
            Column.height("100%");
            Column.backgroundColor("#aabbcc");
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create("侧边栏区域");
            Text.debugLine("entry/src/main/ets/pages/SideBarPage.ets(8:9)", "entry");
            Text.width("100%");
            Text.height("100%");
            Text.fontSize(30);
            Text.textAlign(TextAlign.Center);
        }, Text);
        Text.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/SideBarPage.ets(18:7)", "entry");
            Column.width("100%");
            Column.height("100%");
            Column.backgroundColor("#bbccaa");
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create("侧边栏区域");
            Text.debugLine("entry/src/main/ets/pages/SideBarPage.ets(19:9)", "entry");
            Text.width("100%");
            Text.height("100%");
            Text.fontSize(30);
            Text.textAlign(TextAlign.Center);
        }, Text);
        Text.pop();
        Column.pop();
        SideBarContainer.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "SideBarPage";
    }
}
registerNamedRoute(() => new SideBarPage(undefined, {}), "", { bundleName: "com.xxd.jg", moduleName: "entry", pagePath: "pages/SideBarPage", pageFullPath: "entry/src/main/ets/pages/SideBarPage", integratedHsp: "false" });
