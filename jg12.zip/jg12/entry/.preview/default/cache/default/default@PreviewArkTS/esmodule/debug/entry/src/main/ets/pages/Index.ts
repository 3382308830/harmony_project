if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface Index_Params {
    count?: number;
}
class Index extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__count = new ObservedPropertySimplePU(0, this, "count");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: Index_Params) {
        if (params.count !== undefined) {
            this.count = params.count;
        }
    }
    updateStateVars(params: Index_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__count.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__count.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __count: ObservedPropertySimplePU<number>;
    get count() {
        return this.__count.get();
    }
    set count(newValue: number) {
        this.__count.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Stack.create({ alignContent: Alignment.BottomEnd });
            Stack.debugLine("entry/src/main/ets/pages/Index.ets(6:5)", "entry");
            Stack.height('100%');
            Stack.width('100%');
        }, Stack);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.count.toString());
            Text.debugLine("entry/src/main/ets/pages/Index.ets(7:9)", "entry");
            Text.fontSize(150);
            Text.fontColor(Color.Red);
            Text.fontWeight(FontWeight.Bold);
            Text.size({ width: '100%', height: '70%' });
            Text.textAlign(TextAlign.Center);
            Text.margin({ bottom: 200 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('+');
            Button.debugLine("entry/src/main/ets/pages/Index.ets(14:7)", "entry");
            Button.fontSize(50);
            Button.fontColor('#ff0000');
            Button.fontWeight(FontWeight.Bold);
            Button.backgroundColor(Color.Yellow);
            Button.size({ height: 120, width: 120 });
            Button.margin({ right: 20, bottom: 20 });
            Button.onClick(() => {
                this.count++;
            });
        }, Button);
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('-');
            Button.debugLine("entry/src/main/ets/pages/Index.ets(24:7)", "entry");
            Button.fontSize(50);
            Button.fontColor('#ff0000');
            Button.fontWeight(FontWeight.Bold);
            Button.backgroundColor(Color.Green);
            Button.size({ height: 120, width: 120 });
            Button.margin({ right: 240, bottom: 20 });
            Button.onClick(() => {
                //等于0就停止
                if (this.count > 0) {
                    this.count--;
                }
            });
        }, Button);
        Button.pop();
        Stack.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "Index";
    }
}
registerNamedRoute(() => new Index(undefined, {}), "", { bundleName: "com.xxd.jg", moduleName: "entry", pagePath: "pages/Index", pageFullPath: "entry/src/main/ets/pages/Index", integratedHsp: "false" });
