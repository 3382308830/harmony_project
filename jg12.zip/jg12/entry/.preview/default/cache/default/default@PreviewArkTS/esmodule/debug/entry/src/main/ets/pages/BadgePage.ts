if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface BadgePage_Params {
    counts?: number;
}
class BadgePage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__counts = new ObservedPropertySimplePU(0, this, "counts");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: BadgePage_Params) {
        if (params.counts !== undefined) {
            this.counts = params.counts;
        }
    }
    updateStateVars(params: BadgePage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__counts.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__counts.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __counts: ObservedPropertySimplePU<number>;
    get counts() {
        return this.__counts.get();
    }
    set counts(newValue: number) {
        this.__counts.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 20 });
            Column.debugLine("entry/src/main/ets/pages/BadgePage.ets(7:5)", "entry");
            Column.height('100%');
            Column.width('100%');
            Column.margin({ top: 30 });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Badge.create({
                count: this.counts,
                maxCount: 10,
                position: BadgePosition.RightTop,
                style: {
                    color: Color.White,
                    fontSize: 18,
                    badgeSize: 30,
                    // badgeColor:Color.Blue,
                    // borderWidth:5,
                    // borderColor:Color.Green
                }
            });
            Badge.debugLine("entry/src/main/ets/pages/BadgePage.ets(8:7)", "entry");
            Badge.onClick(() => {
                this.counts++;
            });
        }, Badge);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('角标');
            Text.debugLine("entry/src/main/ets/pages/BadgePage.ets(21:9)", "entry");
            Text.fontSize(48);
            Text.textAlign(TextAlign.Center);
            Text.backgroundColor(Color.Pink);
        }, Text);
        Text.pop();
        Badge.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "BadgePage";
    }
}
registerNamedRoute(() => new BadgePage(undefined, {}), "", { bundleName: "com.xxd.jg", moduleName: "entry", pagePath: "pages/BadgePage", pageFullPath: "entry/src/main/ets/pages/BadgePage", integratedHsp: "false" });
