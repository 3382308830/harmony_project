if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface LinearPage_Params {
}
class LinearPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: LinearPage_Params) {
    }
    updateStateVars(params: LinearPage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 10 });
            Column.debugLine("entry/src/main/ets/pages/LinearPage.ets(5:5)", "entry");
            Column.alignItems(HorizontalAlign.Start);
            Column.padding(10);
            Column.size({ width: "100%", height: '100%' });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 10 });
            Row.debugLine("entry/src/main/ets/pages/LinearPage.ets(6:7)", "entry");
            Row.width('100%');
            Row.height('100%');
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/LinearPage.ets(7:9)", "entry");
            Column.alignItems(HorizontalAlign.Start);
            Column.size({ width: "30%", height: '100%' });
            Column.borderWidth(2);
            Column.borderColor(Color.Pink);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create("Start");
            Text.debugLine("entry/src/main/ets/pages/LinearPage.ets(8:11)", "entry");
            Text.fontSize(22);
            Text.backgroundColor('#aabbcc');
        }, Text);
        Text.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/LinearPage.ets(17:9)", "entry");
            Column.alignItems(HorizontalAlign.Center);
            Column.size({ width: "30%", height: '100%' });
            Column.borderWidth(2);
            Column.borderColor(Color.Pink);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create("Center");
            Text.debugLine("entry/src/main/ets/pages/LinearPage.ets(18:11)", "entry");
            Text.fontSize(22);
            Text.backgroundColor('#aabbcc');
        }, Text);
        Text.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/LinearPage.ets(27:9)", "entry");
            Column.alignItems(HorizontalAlign.End);
            Column.size({ width: "30%", height: '100%' });
            Column.borderWidth(2);
            Column.borderColor(Color.Pink);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create("End");
            Text.debugLine("entry/src/main/ets/pages/LinearPage.ets(28:11)", "entry");
            Text.fontSize(22);
            Text.backgroundColor('#aabbcc');
        }, Text);
        Text.pop();
        Column.pop();
        Row.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "LinearPage";
    }
}
registerNamedRoute(() => new LinearPage(undefined, {}), "", { bundleName: "com.xxd.jg", moduleName: "entry", pagePath: "pages/LinearPage", pageFullPath: "entry/src/main/ets/pages/LinearPage", integratedHsp: "false" });
