if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface SilderPage_Params {
    value?: number;
}
class SilderPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__value = new ObservedPropertySimplePU(0, this, "value");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: SilderPage_Params) {
        if (params.value !== undefined) {
            this.value = params.value;
        }
    }
    updateStateVars(params: SilderPage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__value.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__value.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __value: ObservedPropertySimplePU<number>;
    get value() {
        return this.__value.get();
    }
    set value(newValue: number) {
        this.__value.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/SilderPage.ets(7:5)", "entry");
            Column.height('100%');
            Column.width('100%');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 10 });
            Row.debugLine("entry/src/main/ets/pages/SilderPage.ets(8:7)", "entry");
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Slider.create({
                value: this.value,
                min: 0,
                max: 100,
                step: 1,
                style: SliderStyle.InSet,
                direction: Axis.Horizontal,
                reverse: false
            });
            Slider.debugLine("entry/src/main/ets/pages/SilderPage.ets(10:9)", "entry");
            Slider.width('80%');
            Slider.height(100);
            Slider.margin({ top: 30 });
            Slider.blockColor(Color.Red);
            Slider.trackColor(Color.Yellow);
            Slider.selectedColor(Color.Green);
            Slider.showTips(true);
            Slider.trackThickness(40);
            Slider.showSteps(true);
            Slider.onChange((shuzi) => {
                this.value = shuzi;
            });
        }, Slider);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.value.toString());
            Text.debugLine("entry/src/main/ets/pages/SilderPage.ets(32:9)", "entry");
            Text.fontSize(30);
            Text.fontWeight(500);
            Text.width(80);
            Text.height(50);
            Text.margin({ top: 30 });
        }, Text);
        Text.pop();
        Row.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "SilderPage";
    }
}
registerNamedRoute(() => new SilderPage(undefined, {}), "", { bundleName: "com.xxd.jg", moduleName: "entry", pagePath: "pages/SilderPage", pageFullPath: "entry/src/main/ets/pages/SilderPage", integratedHsp: "false" });
