if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface GridComponentPage_Params {
    shuzi?: Array<string>;
}
class GridComponentPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.shuzi = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10"];
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: GridComponentPage_Params) {
        if (params.shuzi !== undefined) {
            this.shuzi = params.shuzi;
        }
    }
    updateStateVars(params: GridComponentPage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private shuzi: Array<string>;
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/GridComponmentPage.ets(7:5)", "entry");
            Column.padding(10);
            Column.height('100%');
            Column.width('100%');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Grid.create();
            Grid.debugLine("entry/src/main/ets/pages/GridComponmentPage.ets(8:7)", "entry");
            Grid.columnsTemplate("1fr 1fr 1fr");
            Grid.rowsTemplate("1fr 1fr 1fr 1fr 1fr");
            Grid.columnsGap(10);
            Grid.rowsGap(10);
            Grid.width('100%');
            Grid.height(300);
            Grid.backgroundColor(Color.Pink);
        }, Grid);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            //循环渲染，迭代数组
            ForEach.create();
            const forEachItemGenFunction = (_item, index: number) => {
                const item = _item;
                {
                    const itemCreation2 = (elmtId, isInitialRender) => {
                        GridItem.create(() => { }, false);
                        GridItem.columnStart(index == 0 ? 0 : 0);
                        GridItem.columnEnd(index == 0 ? 1 : 0);
                        GridItem.rowStart(index == 6 ? 2 : 0);
                        GridItem.rowEnd(index == 6 ? 3 : 0);
                        GridItem.debugLine("entry/src/main/ets/pages/GridComponmentPage.ets(11:11)", "entry");
                    };
                    const observedDeepRender = () => {
                        this.observeComponentCreation2(itemCreation2, GridItem);
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Text.create(item);
                            Text.debugLine("entry/src/main/ets/pages/GridComponmentPage.ets(12:13)", "entry");
                            Text.fontSize(24);
                            Text.fontWeight(FontWeight.Medium);
                            Text.width('100%');
                            Text.height('100%');
                            Text.backgroundColor(Color.Yellow);
                            Text.textAlign(TextAlign.Center);
                        }, Text);
                        Text.pop();
                        GridItem.pop();
                    };
                    observedDeepRender();
                }
            };
            this.forEachUpdateFunction(elmtId, this.shuzi, forEachItemGenFunction, undefined, true, false);
        }, ForEach);
        //循环渲染，迭代数组
        ForEach.pop();
        Grid.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "GridComponentPage";
    }
}
registerNamedRoute(() => new GridComponentPage(undefined, {}), "", { bundleName: "com.xxd.jg", moduleName: "entry", pagePath: "pages/GridComponmentPage", pageFullPath: "entry/src/main/ets/pages/GridComponmentPage", integratedHsp: "false" });
