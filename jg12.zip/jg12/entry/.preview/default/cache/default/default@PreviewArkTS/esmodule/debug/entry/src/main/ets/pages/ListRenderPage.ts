if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface ListRenderPage_Params {
    message?: string;
    stus?: Student[];
}
import type { Student } from '../class/Student';
import http from "@ohos:net.http";
import JSON from "@ohos:util.json";
import promptAction from "@ohos:promptAction";
class ListRenderPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__message = new ObservedPropertySimplePU('西信大优秀学生', this, "message");
        this.__stus = new ObservedPropertyObjectPU([], this, "stus");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: ListRenderPage_Params) {
        if (params.message !== undefined) {
            this.message = params.message;
        }
        if (params.stus !== undefined) {
            this.stus = params.stus;
        }
    }
    updateStateVars(params: ListRenderPage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__message.purgeDependencyOnElmtId(rmElmtId);
        this.__stus.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__message.aboutToBeDeleted();
        this.__stus.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __message: ObservedPropertySimplePU<string>;
    get message() {
        return this.__message.get();
    }
    set message(newValue: string) {
        this.__message.set(newValue);
    }
    private __stus: ObservedPropertyObjectPU<Student[]>;
    get stus() {
        return this.__stus.get();
    }
    set stus(newValue: Student[]) {
        this.__stus.set(newValue);
    }
    //采用服务器数据初始化
    async aboutToAppear() {
        this.stus = await findAllStudents();
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/ListRenderPage.ets(17:5)", "entry");
            Column.padding(10);
            Column.height('100%');
            Column.width('100%');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.message);
            Text.debugLine("entry/src/main/ets/pages/ListRenderPage.ets(18:7)", "entry");
            Text.id('ListRenderPageHelloWorld');
            Text.fontSize(40);
            Text.fontWeight(FontWeight.Bold);
            Text.margin({ top: 10 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            List.create();
            List.debugLine("entry/src/main/ets/pages/ListRenderPage.ets(24:7)", "entry");
            List.width('100%');
            List.height('90%');
            List.divider({
                strokeWidth: 3,
                color: "#aabbcc"
            });
        }, List);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = (_item, index: number) => {
                const item = _item;
                {
                    const itemCreation = (elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        itemCreation2(elmtId, isInitialRender);
                        if (!isInitialRender) {
                            ListItem.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    };
                    const itemCreation2 = (elmtId, isInitialRender) => {
                        ListItem.create(deepRenderFunction, true);
                        ListItem.onClick(() => {
                            promptAction.showDialog({
                                title: `${item.name}`,
                                message: `学号：${item.id} \n性别：${item.gender} \n专业：${item.major}`
                            });
                        });
                        ListItem.debugLine("entry/src/main/ets/pages/ListRenderPage.ets(26:11)", "entry");
                    };
                    const deepRenderFunction = (elmtId, isInitialRender) => {
                        itemCreation(elmtId, isInitialRender);
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Text.create(item.name + ":" + item.major);
                            Text.debugLine("entry/src/main/ets/pages/ListRenderPage.ets(27:13)", "entry");
                            Text.width('100%');
                            Text.height(40);
                            Text.fontSize(24);
                            Text.fontWeight(FontWeight.Bold);
                            Text.textAlign(TextAlign.Center);
                            Text.backgroundColor(Color.Pink);
                        }, Text);
                        Text.pop();
                        ListItem.pop();
                    };
                    this.observeComponentCreation2(itemCreation2, ListItem);
                    ListItem.pop();
                }
            };
            this.forEachUpdateFunction(elmtId, this.stus, forEachItemGenFunction, undefined, true, false);
        }, ForEach);
        ForEach.pop();
        List.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "ListRenderPage";
    }
}
//定义一个函数，类型是
async function findAllStudents(): Promise<Student[]> {
    //let students:Student[] = [];
    let students: Array<Student> = [];
    let httpRequest = http.createHttp();
    // let url = "http://47.115.220.75:8080/hwstus";
    // "http://47.115.220.75:8080/hwstus"
    let response = httpRequest.request("http://47.115.220.75:8080/hwstus", // 请求的URL
    {
        method: http.RequestMethod.POST,
        header: {
            'Content-Type': 'application/json' // 添加Header，header 默认值就是application/json
        },
        readTimeout: 15000,
        connectTimeout: 15000, // 超时时间
        //extraData: "extra data"                   // 发送请求的参数
    });
    await response.then((data) => {
        // todo
        if (data.responseCode == 200) {
            //将JSON数组转换为对象数组
            students = JSON.parse(`${data.result}`) as Student[];
        }
    });
    return students;
}
registerNamedRoute(() => new ListRenderPage(undefined, {}), "", { bundleName: "com.xxd.jg", moduleName: "entry", pagePath: "pages/ListRenderPage", pageFullPath: "entry/src/main/ets/pages/ListRenderPage", integratedHsp: "false" });
