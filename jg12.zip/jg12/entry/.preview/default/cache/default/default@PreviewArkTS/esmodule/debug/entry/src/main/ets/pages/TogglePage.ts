if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface TogglePage_Params {
}
import promptAction from "@ohos:promptAction";
class TogglePage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: TogglePage_Params) {
    }
    updateStateVars(params: TogglePage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/TogglePage.ets(8:5)", "entry");
            Column.height('100%');
            Column.width('100%');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Toggle.create({ isOn: true, type: ToggleType.Switch });
            Toggle.debugLine("entry/src/main/ets/pages/TogglePage.ets(9:7)", "entry");
            Toggle.width(300);
            Toggle.height(100);
            Toggle.margin({ top: 100 });
            Toggle.selectedColor(Color.Red);
            Toggle.switchPointColor(Color.Green);
            Toggle.onChange((isOn) => {
                if (isOn == true) {
                    promptAction.showToast({
                        message: "开关按钮打开",
                        duration: 4000,
                        bottom: 300 //距离底部距离
                    });
                }
                else {
                    promptAction.showToast({
                        message: "开关按钮关闭",
                        duration: 4000,
                        bottom: 300 //距离底部距离
                    });
                }
            });
        }, Toggle);
        Toggle.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "TogglePage";
    }
}
registerNamedRoute(() => new TogglePage(undefined, {}), "", { bundleName: "com.xxd.jg", moduleName: "entry", pagePath: "pages/TogglePage", pageFullPath: "entry/src/main/ets/pages/TogglePage", integratedHsp: "false" });
