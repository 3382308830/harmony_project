if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface ListPage_Params {
}
import promptAction from "@ohos:promptAction";
import router from "@ohos:router";
class ListPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: ListPage_Params) {
    }
    updateStateVars(params: ListPage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/ListPage.ets(9:5)", "entry");
            Column.height('100%');
            Column.width('100%');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            List.create({ space: 10 });
            List.debugLine("entry/src/main/ets/pages/ListPage.ets(10:7)", "entry");
            List.height('100%');
            List.width('100%');
            List.alignListItem(ListItemAlign.Center);
        }, List);
        {
            const itemCreation = (elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                itemCreation2(elmtId, isInitialRender);
                if (!isInitialRender) {
                    //第一列表
                    ListItem.pop();
                }
                ViewStackProcessor.StopGetAccessRecording();
            };
            const itemCreation2 = (elmtId, isInitialRender) => {
                ListItem.create(deepRenderFunction, true);
                //第一列表
                ListItem.onClick(() => {
                    promptAction.showToast({
                        message: "计算机工程学院",
                        duration: 4000,
                        bottom: 300 //距离底部的距离
                    });
                });
                ListItem.debugLine("entry/src/main/ets/pages/ListPage.ets(12:9)", "entry");
            };
            const deepRenderFunction = (elmtId, isInitialRender) => {
                itemCreation(elmtId, isInitialRender);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Row.create({ space: 10 });
                    Row.debugLine("entry/src/main/ets/pages/ListPage.ets(13:11)", "entry");
                    Row.backgroundColor(0xaabbcc);
                    Row.margin({ top: 30 });
                    Row.borderRadius(6);
                }, Row);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Image.create({ "id": 16777228, "type": 20000, params: [], "bundleName": "com.xxd.jg", "moduleName": "entry" });
                    Image.debugLine("entry/src/main/ets/pages/ListPage.ets(14:13)", "entry");
                    Image.width(50);
                    Image.height(50);
                }, Image);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create('计算机工程学院');
                    Text.debugLine("entry/src/main/ets/pages/ListPage.ets(17:13)", "entry");
                    Text.width('65%');
                    Text.height(50);
                    Text.fontSize(30);
                    Text.textAlign(TextAlign.Center);
                    Text.fontWeight(FontWeight.Medium);
                }, Text);
                Text.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Image.create({ "id": 16777231, "type": 20000, params: [], "bundleName": "com.xxd.jg", "moduleName": "entry" });
                    Image.debugLine("entry/src/main/ets/pages/ListPage.ets(23:13)", "entry");
                    Image.width(50);
                    Image.height(50);
                    Image.onClick(() => {
                        router.push({
                            url: "pages/Index"
                        });
                    });
                }, Image);
                Row.pop();
                //第一列表
                ListItem.pop();
            };
            this.observeComponentCreation2(itemCreation2, ListItem);
            //第一列表
            ListItem.pop();
        }
        {
            const itemCreation = (elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                itemCreation2(elmtId, isInitialRender);
                if (!isInitialRender) {
                    //第二列表
                    ListItem.pop();
                }
                ViewStackProcessor.StopGetAccessRecording();
            };
            const itemCreation2 = (elmtId, isInitialRender) => {
                ListItem.create(deepRenderFunction, true);
                ListItem.debugLine("entry/src/main/ets/pages/ListPage.ets(44:9)", "entry");
            };
            const deepRenderFunction = (elmtId, isInitialRender) => {
                itemCreation(elmtId, isInitialRender);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create('信息安全管理学院');
                    Text.debugLine("entry/src/main/ets/pages/ListPage.ets(45:11)", "entry");
                    Text.width('70%');
                    Text.height(50);
                    Text.fontSize(30);
                    Text.fontWeight(FontWeight.Medium);
                    Text.backgroundColor(0xaabbcc);
                    Text.margin({ top: 0 });
                    Text.borderRadius(6);
                    Text.textAlign(TextAlign.Center);
                }, Text);
                Text.pop();
                //第二列表
                ListItem.pop();
            };
            this.observeComponentCreation2(itemCreation2, ListItem);
            //第二列表
            ListItem.pop();
        }
        {
            const itemCreation = (elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                itemCreation2(elmtId, isInitialRender);
                if (!isInitialRender) {
                    //第三列表
                    ListItem.pop();
                }
                ViewStackProcessor.StopGetAccessRecording();
            };
            const itemCreation2 = (elmtId, isInitialRender) => {
                ListItem.create(deepRenderFunction, true);
                ListItem.debugLine("entry/src/main/ets/pages/ListPage.ets(56:9)", "entry");
            };
            const deepRenderFunction = (elmtId, isInitialRender) => {
                itemCreation(elmtId, isInitialRender);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create('网络工程管理学院');
                    Text.debugLine("entry/src/main/ets/pages/ListPage.ets(57:11)", "entry");
                    Text.width('70%');
                    Text.height(50);
                    Text.fontSize(30);
                    Text.fontWeight(FontWeight.Medium);
                    Text.backgroundColor(0xaabbcc);
                    Text.margin({ top: 0 });
                    Text.borderRadius(6);
                    Text.textAlign(TextAlign.Center);
                }, Text);
                Text.pop();
                //第三列表
                ListItem.pop();
            };
            this.observeComponentCreation2(itemCreation2, ListItem);
            //第三列表
            ListItem.pop();
        }
        {
            const itemCreation = (elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                itemCreation2(elmtId, isInitialRender);
                if (!isInitialRender) {
                    //第四列表
                    ListItem.pop();
                }
                ViewStackProcessor.StopGetAccessRecording();
            };
            const itemCreation2 = (elmtId, isInitialRender) => {
                ListItem.create(deepRenderFunction, true);
                ListItem.debugLine("entry/src/main/ets/pages/ListPage.ets(68:9)", "entry");
            };
            const deepRenderFunction = (elmtId, isInitialRender) => {
                itemCreation(elmtId, isInitialRender);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create('数字媒体学院');
                    Text.debugLine("entry/src/main/ets/pages/ListPage.ets(69:11)", "entry");
                    Text.width('70%');
                    Text.height(50);
                    Text.fontSize(30);
                    Text.fontWeight(FontWeight.Medium);
                    Text.backgroundColor(0xaabbcc);
                    Text.margin({ top: 0 });
                    Text.borderRadius(6);
                    Text.textAlign(TextAlign.Center);
                }, Text);
                Text.pop();
                //第四列表
                ListItem.pop();
            };
            this.observeComponentCreation2(itemCreation2, ListItem);
            //第四列表
            ListItem.pop();
        }
        {
            const itemCreation = (elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                itemCreation2(elmtId, isInitialRender);
                if (!isInitialRender) {
                    //第五列表
                    ListItem.pop();
                }
                ViewStackProcessor.StopGetAccessRecording();
            };
            const itemCreation2 = (elmtId, isInitialRender) => {
                ListItem.create(deepRenderFunction, true);
                ListItem.debugLine("entry/src/main/ets/pages/ListPage.ets(80:9)", "entry");
            };
            const deepRenderFunction = (elmtId, isInitialRender) => {
                itemCreation(elmtId, isInitialRender);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create('汉语言文学学院');
                    Text.debugLine("entry/src/main/ets/pages/ListPage.ets(81:11)", "entry");
                    Text.width('70%');
                    Text.height(50);
                    Text.fontSize(30);
                    Text.fontWeight(FontWeight.Medium);
                    Text.backgroundColor(0xaabbcc);
                    Text.margin({ top: 0 });
                    Text.borderRadius(6);
                    Text.textAlign(TextAlign.Center);
                }, Text);
                Text.pop();
                //第五列表
                ListItem.pop();
            };
            this.observeComponentCreation2(itemCreation2, ListItem);
            //第五列表
            ListItem.pop();
        }
        {
            const itemCreation = (elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                itemCreation2(elmtId, isInitialRender);
                if (!isInitialRender) {
                    //第六列表
                    ListItem.pop();
                }
                ViewStackProcessor.StopGetAccessRecording();
            };
            const itemCreation2 = (elmtId, isInitialRender) => {
                ListItem.create(deepRenderFunction, true);
                ListItem.debugLine("entry/src/main/ets/pages/ListPage.ets(92:9)", "entry");
            };
            const deepRenderFunction = (elmtId, isInitialRender) => {
                itemCreation(elmtId, isInitialRender);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create('建筑工程学院');
                    Text.debugLine("entry/src/main/ets/pages/ListPage.ets(93:11)", "entry");
                    Text.width('70%');
                    Text.height(50);
                    Text.fontSize(30);
                    Text.fontWeight(FontWeight.Medium);
                    Text.backgroundColor(0xaabbcc);
                    Text.margin({ top: 0 });
                    Text.borderRadius(6);
                    Text.textAlign(TextAlign.Center);
                }, Text);
                Text.pop();
                //第六列表
                ListItem.pop();
            };
            this.observeComponentCreation2(itemCreation2, ListItem);
            //第六列表
            ListItem.pop();
        }
        {
            const itemCreation = (elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                itemCreation2(elmtId, isInitialRender);
                if (!isInitialRender) {
                    //第七列表
                    ListItem.pop();
                }
                ViewStackProcessor.StopGetAccessRecording();
            };
            const itemCreation2 = (elmtId, isInitialRender) => {
                ListItem.create(deepRenderFunction, true);
                ListItem.debugLine("entry/src/main/ets/pages/ListPage.ets(104:9)", "entry");
            };
            const deepRenderFunction = (elmtId, isInitialRender) => {
                itemCreation(elmtId, isInitialRender);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create('航空航天学院');
                    Text.debugLine("entry/src/main/ets/pages/ListPage.ets(105:11)", "entry");
                    Text.width('70%');
                    Text.height(50);
                    Text.fontSize(30);
                    Text.fontWeight(FontWeight.Medium);
                    Text.backgroundColor(0xaabbcc);
                    Text.margin({ top: 0 });
                    Text.borderRadius(6);
                    Text.textAlign(TextAlign.Center);
                }, Text);
                Text.pop();
                //第七列表
                ListItem.pop();
            };
            this.observeComponentCreation2(itemCreation2, ListItem);
            //第七列表
            ListItem.pop();
        }
        {
            const itemCreation = (elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                itemCreation2(elmtId, isInitialRender);
                if (!isInitialRender) {
                    //第八列表
                    ListItem.pop();
                }
                ViewStackProcessor.StopGetAccessRecording();
            };
            const itemCreation2 = (elmtId, isInitialRender) => {
                ListItem.create(deepRenderFunction, true);
                ListItem.debugLine("entry/src/main/ets/pages/ListPage.ets(116:9)", "entry");
            };
            const deepRenderFunction = (elmtId, isInitialRender) => {
                itemCreation(elmtId, isInitialRender);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create('人工智能学院');
                    Text.debugLine("entry/src/main/ets/pages/ListPage.ets(117:11)", "entry");
                    Text.width('70%');
                    Text.height(50);
                    Text.fontSize(30);
                    Text.fontWeight(FontWeight.Medium);
                    Text.backgroundColor(0xaabbcc);
                    Text.margin({ top: 0 });
                    Text.borderRadius(6);
                    Text.textAlign(TextAlign.Center);
                }, Text);
                Text.pop();
                //第八列表
                ListItem.pop();
            };
            this.observeComponentCreation2(itemCreation2, ListItem);
            //第八列表
            ListItem.pop();
        }
        {
            const itemCreation = (elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                itemCreation2(elmtId, isInitialRender);
                if (!isInitialRender) {
                    //第九列表
                    ListItem.pop();
                }
                ViewStackProcessor.StopGetAccessRecording();
            };
            const itemCreation2 = (elmtId, isInitialRender) => {
                ListItem.create(deepRenderFunction, true);
                ListItem.debugLine("entry/src/main/ets/pages/ListPage.ets(128:9)", "entry");
            };
            const deepRenderFunction = (elmtId, isInitialRender) => {
                itemCreation(elmtId, isInitialRender);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create('大数据学院');
                    Text.debugLine("entry/src/main/ets/pages/ListPage.ets(129:11)", "entry");
                    Text.width('70%');
                    Text.height(50);
                    Text.fontSize(30);
                    Text.fontWeight(FontWeight.Medium);
                    Text.backgroundColor(0xaabbcc);
                    Text.margin({ top: 0 });
                    Text.borderRadius(6);
                    Text.textAlign(TextAlign.Center);
                }, Text);
                Text.pop();
                //第九列表
                ListItem.pop();
            };
            this.observeComponentCreation2(itemCreation2, ListItem);
            //第九列表
            ListItem.pop();
        }
        {
            const itemCreation = (elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                itemCreation2(elmtId, isInitialRender);
                if (!isInitialRender) {
                    //第十列表
                    ListItem.pop();
                }
                ViewStackProcessor.StopGetAccessRecording();
            };
            const itemCreation2 = (elmtId, isInitialRender) => {
                ListItem.create(deepRenderFunction, true);
                ListItem.debugLine("entry/src/main/ets/pages/ListPage.ets(140:9)", "entry");
            };
            const deepRenderFunction = (elmtId, isInitialRender) => {
                itemCreation(elmtId, isInitialRender);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create('哲学学院');
                    Text.debugLine("entry/src/main/ets/pages/ListPage.ets(141:11)", "entry");
                    Text.width('70%');
                    Text.height(50);
                    Text.fontSize(30);
                    Text.fontWeight(FontWeight.Medium);
                    Text.backgroundColor(0xaabbcc);
                    Text.margin({ top: 0 });
                    Text.borderRadius(6);
                    Text.textAlign(TextAlign.Center);
                }, Text);
                Text.pop();
                //第十列表
                ListItem.pop();
            };
            this.observeComponentCreation2(itemCreation2, ListItem);
            //第十列表
            ListItem.pop();
        }
        {
            const itemCreation = (elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                itemCreation2(elmtId, isInitialRender);
                if (!isInitialRender) {
                    //第十一列表
                    ListItem.pop();
                }
                ViewStackProcessor.StopGetAccessRecording();
            };
            const itemCreation2 = (elmtId, isInitialRender) => {
                ListItem.create(deepRenderFunction, true);
                ListItem.debugLine("entry/src/main/ets/pages/ListPage.ets(152:9)", "entry");
            };
            const deepRenderFunction = (elmtId, isInitialRender) => {
                itemCreation(elmtId, isInitialRender);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create('法学院');
                    Text.debugLine("entry/src/main/ets/pages/ListPage.ets(153:11)", "entry");
                    Text.width('70%');
                    Text.height(50);
                    Text.fontSize(30);
                    Text.fontWeight(FontWeight.Medium);
                    Text.backgroundColor(0xaabbcc);
                    Text.margin({ top: 0 });
                    Text.borderRadius(6);
                    Text.textAlign(TextAlign.Center);
                }, Text);
                Text.pop();
                //第十一列表
                ListItem.pop();
            };
            this.observeComponentCreation2(itemCreation2, ListItem);
            //第十一列表
            ListItem.pop();
        }
        {
            const itemCreation = (elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                itemCreation2(elmtId, isInitialRender);
                if (!isInitialRender) {
                    //第十二列表
                    ListItem.pop();
                }
                ViewStackProcessor.StopGetAccessRecording();
            };
            const itemCreation2 = (elmtId, isInitialRender) => {
                ListItem.create(deepRenderFunction, true);
                ListItem.debugLine("entry/src/main/ets/pages/ListPage.ets(164:9)", "entry");
            };
            const deepRenderFunction = (elmtId, isInitialRender) => {
                itemCreation(elmtId, isInitialRender);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create('电子信息学院');
                    Text.debugLine("entry/src/main/ets/pages/ListPage.ets(165:11)", "entry");
                    Text.width('70%');
                    Text.height(50);
                    Text.fontSize(30);
                    Text.fontWeight(FontWeight.Medium);
                    Text.backgroundColor(0xaabbcc);
                    Text.margin({ top: 0 });
                    Text.borderRadius(6);
                    Text.textAlign(TextAlign.Center);
                }, Text);
                Text.pop();
                //第十二列表
                ListItem.pop();
            };
            this.observeComponentCreation2(itemCreation2, ListItem);
            //第十二列表
            ListItem.pop();
        }
        {
            const itemCreation = (elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                itemCreation2(elmtId, isInitialRender);
                if (!isInitialRender) {
                    //第十三列表
                    ListItem.pop();
                }
                ViewStackProcessor.StopGetAccessRecording();
            };
            const itemCreation2 = (elmtId, isInitialRender) => {
                ListItem.create(deepRenderFunction, true);
                ListItem.debugLine("entry/src/main/ets/pages/ListPage.ets(176:9)", "entry");
            };
            const deepRenderFunction = (elmtId, isInitialRender) => {
                itemCreation(elmtId, isInitialRender);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create('土木工程学院');
                    Text.debugLine("entry/src/main/ets/pages/ListPage.ets(177:11)", "entry");
                    Text.width('70%');
                    Text.height(50);
                    Text.fontSize(30);
                    Text.fontWeight(FontWeight.Medium);
                    Text.backgroundColor(0xaabbcc);
                    Text.margin({ top: 0 });
                    Text.borderRadius(6);
                    Text.textAlign(TextAlign.Center);
                }, Text);
                Text.pop();
                //第十三列表
                ListItem.pop();
            };
            this.observeComponentCreation2(itemCreation2, ListItem);
            //第十三列表
            ListItem.pop();
        }
        {
            const itemCreation = (elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                itemCreation2(elmtId, isInitialRender);
                if (!isInitialRender) {
                    //第十四列表
                    ListItem.pop();
                }
                ViewStackProcessor.StopGetAccessRecording();
            };
            const itemCreation2 = (elmtId, isInitialRender) => {
                ListItem.create(deepRenderFunction, true);
                ListItem.debugLine("entry/src/main/ets/pages/ListPage.ets(188:9)", "entry");
            };
            const deepRenderFunction = (elmtId, isInitialRender) => {
                itemCreation(elmtId, isInitialRender);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create('金融学院');
                    Text.debugLine("entry/src/main/ets/pages/ListPage.ets(189:11)", "entry");
                    Text.width('70%');
                    Text.height(50);
                    Text.fontSize(30);
                    Text.fontWeight(FontWeight.Medium);
                    Text.backgroundColor(0xaabbcc);
                    Text.margin({ top: 0 });
                    Text.borderRadius(6);
                    Text.textAlign(TextAlign.Center);
                }, Text);
                Text.pop();
                //第十四列表
                ListItem.pop();
            };
            this.observeComponentCreation2(itemCreation2, ListItem);
            //第十四列表
            ListItem.pop();
        }
        List.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "ListPage";
    }
}
registerNamedRoute(() => new ListPage(undefined, {}), "", { bundleName: "com.xxd.jg", moduleName: "entry", pagePath: "pages/ListPage", pageFullPath: "entry/src/main/ets/pages/ListPage", integratedHsp: "false" });
