if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface RelativePage_Params {
}
class RelativePage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: RelativePage_Params) {
    }
    updateStateVars(params: RelativePage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 10 });
            Column.debugLine("entry/src/main/ets/pages/RelativePage.ets(5:5)", "entry");
            Column.width("100%");
            Column.height("100%");
            Column.backgroundColor("#aabbcc");
            Column.padding({ left: 50, top: 10, right: 50, bottom: 10 });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            RelativeContainer.create();
            RelativeContainer.debugLine("entry/src/main/ets/pages/RelativePage.ets(6:7)", "entry");
            RelativeContainer.width("100%");
            RelativeContainer.height(90);
            RelativeContainer.backgroundColor(Color.Pink);
        }, RelativeContainer);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create("上端");
            Text.debugLine("entry/src/main/ets/pages/RelativePage.ets(7:9)", "entry");
            Text.fontSize(25);
            Text.width(120);
            Text.height(40);
            Text.backgroundColor("#bbccaa");
            Text.alignRules({
                top: {
                    anchor: "__container__",
                    align: VerticalAlign.Top
                }
            });
            Text.id("test");
        }, Text);
        Text.pop();
        RelativeContainer.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            RelativeContainer.create();
            RelativeContainer.debugLine("entry/src/main/ets/pages/RelativePage.ets(24:7)", "entry");
            RelativeContainer.width("100%");
            RelativeContainer.height(90);
            RelativeContainer.backgroundColor(Color.Pink);
        }, RelativeContainer);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create("中间");
            Text.debugLine("entry/src/main/ets/pages/RelativePage.ets(25:9)", "entry");
            Text.fontSize(25);
            Text.width(120);
            Text.height(40);
            Text.backgroundColor("#bbccaa");
            Text.alignRules({
                top: {
                    anchor: "__container__",
                    align: VerticalAlign.Center
                }
            });
            Text.id("test");
        }, Text);
        Text.pop();
        RelativeContainer.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            RelativeContainer.create();
            RelativeContainer.debugLine("entry/src/main/ets/pages/RelativePage.ets(42:7)", "entry");
            RelativeContainer.width("100%");
            RelativeContainer.height(90);
            RelativeContainer.backgroundColor(Color.Pink);
        }, RelativeContainer);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create("下端");
            Text.debugLine("entry/src/main/ets/pages/RelativePage.ets(43:9)", "entry");
            Text.fontSize(25);
            Text.width(120);
            Text.height(40);
            Text.backgroundColor("#bbccaa");
            Text.alignRules({
                top: {
                    anchor: "__container__",
                    align: VerticalAlign.Bottom
                }
            });
            Text.id("test");
        }, Text);
        Text.pop();
        RelativeContainer.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "RelativePage";
    }
}
registerNamedRoute(() => new RelativePage(undefined, {}), "", { bundleName: "com.xxd.jg", moduleName: "entry", pagePath: "pages/RelativePage", pageFullPath: "entry/src/main/ets/pages/RelativePage", integratedHsp: "false" });
