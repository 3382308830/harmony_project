if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface CounterPage_Params {
    count?: number;
}
class CounterPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__count = new ObservedPropertySimplePU(0, this, "count");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: CounterPage_Params) {
        if (params.count !== undefined) {
            this.count = params.count;
        }
    }
    updateStateVars(params: CounterPage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__count.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__count.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    //number 数字类型
    private __count: ObservedPropertySimplePU<number>;
    get count() {
        return this.__count.get();
    }
    set count(newValue: number) {
        this.__count.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 20 });
            Column.debugLine("entry/src/main/ets/pages/CounterPage.ets(9:5)", "entry");
            Column.height('100%');
            Column.width('100%');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Counter.create();
            Counter.debugLine("entry/src/main/ets/pages/CounterPage.ets(10:7)", "entry");
            Counter.width(200);
            Counter.height(60);
        }, Counter);
        Counter.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Counter.create();
            Counter.debugLine("entry/src/main/ets/pages/CounterPage.ets(13:7)", "entry");
            Counter.onInc(() => {
                this.count++;
            });
            Counter.onDec(() => {
                if (this.count > 0) {
                    this.count--;
                }
            });
        }, Counter);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.count.toString());
            Text.debugLine("entry/src/main/ets/pages/CounterPage.ets(14:9)", "entry");
            Text.fontSize(18);
        }, Text);
        Text.pop();
        Counter.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "CounterPage";
    }
}
registerNamedRoute(() => new CounterPage(undefined, {}), "", { bundleName: "com.xxd.jg", moduleName: "entry", pagePath: "pages/CounterPage", pageFullPath: "entry/src/main/ets/pages/CounterPage", integratedHsp: "false" });
