if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface ProgressPage_Params {
    value?: number;
    intervalID?: number;
}
class ProgressPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__value = new ObservedPropertySimplePU(0, this, "value");
        this.intervalID = -1;
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: ProgressPage_Params) {
        if (params.value !== undefined) {
            this.value = params.value;
        }
        if (params.intervalID !== undefined) {
            this.intervalID = params.intervalID;
        }
    }
    updateStateVars(params: ProgressPage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__value.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__value.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __value: ObservedPropertySimplePU<number>;
    get value() {
        return this.__value.get();
    }
    set value(newValue: number) {
        this.__value.set(newValue);
    }
    private intervalID: number;
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 30 });
            Column.debugLine("entry/src/main/ets/pages/ProgressPage.ets(8:5)", "entry");
            Column.height('100%');
            Column.width('100%');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 圆点进度条
            Progress.create({
                value: this.value,
                type: ProgressType.ScaleRing // 设置进度条的样式为环形刻度样式
            });
            Progress.debugLine("entry/src/main/ets/pages/ProgressPage.ets(10:7)", "entry");
            // 圆点进度条
            Progress.size({ width: 80, height: 80 });
            // 圆点进度条
            Progress.margin({ top: 20 });
            // 圆点进度条
            Progress.color(0xff0000);
            // 圆点进度条
            Progress.style({ strokeWidth: 5, scaleCount: 24, scaleWidth: 5 });
        }, Progress);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            //胶囊进度条
            Progress.create({
                value: this.value,
                total: 100,
                type: ProgressType.Capsule // 设置进度条的样式为胶囊样式
            });
            Progress.debugLine("entry/src/main/ets/pages/ProgressPage.ets(20:7)", "entry");
            //胶囊进度条
            Progress.size({ width: 120, height: 50 });
            //胶囊进度条
            Progress.color(Color.Green);
        }, Progress);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            //圆形进度条
            Progress.create({
                value: this.value,
                total: 100,
                type: ProgressType.Eclipse // 设置进度条的样式为圆形样式
            });
            Progress.debugLine("entry/src/main/ets/pages/ProgressPage.ets(29:7)", "entry");
            //圆形进度条
            Progress.size({ width: 80, height: 80 });
        }, Progress);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            //线性进度条
            Progress.create({
                value: this.value,
                total: 100,
                type: ProgressType.Linear // 设置进度条的样式为条形样式
            });
            Progress.debugLine("entry/src/main/ets/pages/ProgressPage.ets(37:7)", "entry");
            //线性进度条
            Progress.size({ width: '100%', height: 40 });
        }, Progress);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            //圆环进度条
            Progress.create({
                value: this.value,
                total: 100,
                type: ProgressType.Ring // 设置进度条的样式为环形样式
            });
            Progress.debugLine("entry/src/main/ets/pages/ProgressPage.ets(45:7)", "entry");
            //圆环进度条
            Progress.size({ width: 80, height: 80 });
            //圆环进度条
            Progress.color('#ff0000');
        }, Progress);
        Column.pop();
    }
    aboutToAppear(): void {
        this.intervalID = setInterval(() => {
            this.value++;
            if (this.value > 100) {
                clearInterval(this.intervalID); //取消定时器
            }
        }, 100);
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "ProgressPage";
    }
}
registerNamedRoute(() => new ProgressPage(undefined, {}), "", { bundleName: "com.xxd.jg", moduleName: "entry", pagePath: "pages/ProgressPage", pageFullPath: "entry/src/main/ets/pages/ProgressPage", integratedHsp: "false" });
