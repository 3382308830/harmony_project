if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface ForEachPage_Params {
    university?: string[];
}
class ForEachPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.university = ["清华大学", "北京大学", "西安交通大学", "西安信息职业大学"];
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: ForEachPage_Params) {
        if (params.university !== undefined) {
            this.university = params.university;
        }
    }
    updateStateVars(params: ForEachPage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private university: string[];
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 10 });
            Column.debugLine("entry/src/main/ets/pages/ForEachPage.ets(7:5)", "entry");
            Column.height('100%');
            Column.width('100%');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = (_item, index: number) => {
                const item = _item;
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Button.createWithLabel(item);
                    Button.debugLine("entry/src/main/ets/pages/ForEachPage.ets(9:9)", "entry");
                    Button.width('80%');
                    Button.height(50);
                    Button.fontSize(30);
                    Button.fontWeight(FontWeight.Medium);
                    Button.backgroundColor(0xaabbcc);
                    Button.type(ButtonType.Normal);
                    Button.borderRadius(6);
                }, Button);
                Button.pop();
            };
            this.forEachUpdateFunction(elmtId, this.university, forEachItemGenFunction, undefined, true, false);
        }, ForEach);
        ForEach.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "ForEachPage";
    }
}
registerNamedRoute(() => new ForEachPage(undefined, {}), "", { bundleName: "com.xxd.jg", moduleName: "entry", pagePath: "pages/ForEachPage", pageFullPath: "entry/src/main/ets/pages/ForEachPage", integratedHsp: "false" });
