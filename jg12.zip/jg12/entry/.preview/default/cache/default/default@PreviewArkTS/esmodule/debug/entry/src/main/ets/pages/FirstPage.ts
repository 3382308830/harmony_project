if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface FirstPage_Params {
    returnmessage?: string;
}
import router from "@ohos:router";
class user {
    name: string = '';
    constructor(msg: string) {
        this.name = msg;
    }
}
class returnmsg {
    message: string = '';
    constructor(msg: string) {
        this.message = msg;
    }
}
class FirstPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__returnmessage = new ObservedPropertySimplePU('', this, "returnmessage");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: FirstPage_Params) {
        if (params.returnmessage !== undefined) {
            this.returnmessage = params.returnmessage;
        }
    }
    updateStateVars(params: FirstPage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__returnmessage.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__returnmessage.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __returnmessage: ObservedPropertySimplePU<string>;
    get returnmessage() {
        return this.__returnmessage.get();
    }
    set returnmessage(newValue: string) {
        this.__returnmessage.set(newValue);
    }
    onPageShow(): void {
        let returnmsg = router.getParams() as returnmsg;
        if (returnmsg) {
            this.returnmessage = returnmsg.message;
        }
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/FirstPage.ets(33:5)", "entry");
            Column.height('100%');
            Column.width('100%');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('下一个页面');
            Button.debugLine("entry/src/main/ets/pages/FirstPage.ets(34:7)", "entry");
            Button.type(ButtonType.Normal);
            Button.borderRadius(6);
            Button.borderColor(0xff0000);
            Button.borderWidth(0);
            Button.backgroundColor(0x969696);
            Button.fontSize(30);
            Button.fontColor(0x000000);
            Button.fontWeight(FontWeight.Medium);
            Button.margin({ top: 30 });
            Button.width('80%');
            Button.height(50);
            Button.onClick(() => {
                router.push({
                    url: "pages/SecondPage",
                    params: new user('杨佳钰')
                });
            });
        }, Button);
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/FirstPage.ets(53:7)", "entry");
            Row.height(50);
            Row.width('80%');
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('登录状态:');
            Text.debugLine("entry/src/main/ets/pages/FirstPage.ets(54:9)", "entry");
            Text.fontSize(30);
            Text.fontWeight(FontWeight.Medium);
            Text.width('50%');
            Text.height('50%');
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.returnmessage);
            Text.debugLine("entry/src/main/ets/pages/FirstPage.ets(60:9)", "entry");
            Text.fontSize(30);
            Text.fontWeight(FontWeight.Medium);
            Text.width('50%');
            Text.height('50%');
        }, Text);
        Text.pop();
        Row.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "FirstPage";
    }
}
registerNamedRoute(() => new FirstPage(undefined, {}), "", { bundleName: "com.xxd.jg", moduleName: "entry", pagePath: "pages/FirstPage", pageFullPath: "entry/src/main/ets/pages/FirstPage", integratedHsp: "false" });
