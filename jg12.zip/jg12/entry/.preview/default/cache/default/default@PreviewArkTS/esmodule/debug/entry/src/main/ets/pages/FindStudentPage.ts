if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface FindStudentPage_Params {
    stuid?: string;
    student?: Student;
    stuname?: string;
}
import http from "@ohos:net.http";
import type { Student } from '../class/Student';
import JSON from "@ohos:util.json";
class FindStudentPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__stuid = new ObservedPropertySimplePU('', this, "stuid");
        this.student = null!;
        this.__stuname = new ObservedPropertySimplePU('', this, "stuname");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: FindStudentPage_Params) {
        if (params.stuid !== undefined) {
            this.stuid = params.stuid;
        }
        if (params.student !== undefined) {
            this.student = params.student;
        }
        if (params.stuname !== undefined) {
            this.stuname = params.stuname;
        }
    }
    updateStateVars(params: FindStudentPage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__stuid.purgeDependencyOnElmtId(rmElmtId);
        this.__stuname.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__stuid.aboutToBeDeleted();
        this.__stuname.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __stuid: ObservedPropertySimplePU<string>;
    get stuid() {
        return this.__stuid.get();
    }
    set stuid(newValue: string) {
        this.__stuid.set(newValue);
    }
    private student: Student;
    private __stuname: ObservedPropertySimplePU<string>;
    get stuname() {
        return this.__stuname.get();
    }
    set stuname(newValue: string) {
        this.__stuname.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 10 });
            Column.debugLine("entry/src/main/ets/pages/FindStudentPage.ets(13:5)", "entry");
            Column.padding(10);
            Column.height('100%');
            Column.width('100%');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 10 });
            Row.debugLine("entry/src/main/ets/pages/FindStudentPage.ets(14:7)", "entry");
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create("学号：");
            Text.debugLine("entry/src/main/ets/pages/FindStudentPage.ets(15:9)", "entry");
            Text.fontSize(24);
            Text.fontWeight(FontWeight.Medium);
            Text.layoutWeight(1);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: '请求输入学号' });
            TextInput.debugLine("entry/src/main/ets/pages/FindStudentPage.ets(19:9)", "entry");
            TextInput.fontSize(24);
            TextInput.fontWeight(FontWeight.Medium);
            TextInput.layoutWeight(2);
            TextInput.borderRadius(5);
            TextInput.onChange((value) => {
                this.stuid = value;
            });
        }, TextInput);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('查询');
            Button.debugLine("entry/src/main/ets/pages/FindStudentPage.ets(27:9)", "entry");
            Button.fontSize(24);
            Button.fontWeight(FontWeight.Medium);
            Button.layoutWeight(1);
            Button.type(ButtonType.Normal);
            Button.borderRadius(5);
            Button.onClick(() => {
                let url = "http://47.115.220.75:8080/huawei";
                let httpRequest = http.createHttp();
                httpRequest.request(url, // 请求的URL
                {
                    method: http.RequestMethod.POST,
                    header: {
                        'Content-Type': 'application/json' // 添加Header，header 默认值就是application/json
                    },
                    readTimeout: 15000,
                    connectTimeout: 15000,
                    extraData: {
                        id: this.stuid
                    } // 发送请求的额外数据
                }, (error, data) => {
                    if (error) {
                        console.log("网络错误");
                    }
                    else if (data.responseCode == http.ResponseCode.OK) {
                        this.student = JSON.parse(`${data.result}`) as Student;
                        this.stuname = this.student.name as string;
                    }
                });
            });
        }, Button);
        Button.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 10 });
            Row.debugLine("entry/src/main/ets/pages/FindStudentPage.ets(60:7)", "entry");
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('姓名：');
            Text.debugLine("entry/src/main/ets/pages/FindStudentPage.ets(61:9)", "entry");
            Text.fontSize(24);
            Text.fontWeight(FontWeight.Medium);
            Text.layoutWeight(1);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.stuname);
            Text.debugLine("entry/src/main/ets/pages/FindStudentPage.ets(65:9)", "entry");
            Text.fontSize(24);
            Text.fontWeight(FontWeight.Medium);
            Text.layoutWeight(3);
        }, Text);
        Text.pop();
        Row.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "FindStudentPage";
    }
}
registerNamedRoute(() => new FindStudentPage(undefined, {}), "", { bundleName: "com.xxd.jg", moduleName: "entry", pagePath: "pages/FindStudentPage", pageFullPath: "entry/src/main/ets/pages/FindStudentPage", integratedHsp: "false" });
