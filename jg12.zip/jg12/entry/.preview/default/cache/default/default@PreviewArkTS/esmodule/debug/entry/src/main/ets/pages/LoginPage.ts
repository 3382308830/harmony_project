if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface LoginPage_Params {
    account?: string;
    password?: string;
}
import promptAction from "@ohos:promptAction";
import router from "@ohos:router";
class LoginPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__account = new ObservedPropertySimplePU('', this, "account");
        this.__password = new ObservedPropertySimplePU('', this, "password");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: LoginPage_Params) {
        if (params.account !== undefined) {
            this.account = params.account;
        }
        if (params.password !== undefined) {
            this.password = params.password;
        }
    }
    updateStateVars(params: LoginPage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__account.purgeDependencyOnElmtId(rmElmtId);
        this.__password.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__account.aboutToBeDeleted();
        this.__password.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    // 状态标识符，值改变调用 build()方法刷新页面
    private __account: ObservedPropertySimplePU<string>;
    get account() {
        return this.__account.get();
    }
    set account(newValue: string) {
        this.__account.set(newValue);
    }
    private __password: ObservedPropertySimplePU<string>;
    get password() {
        return this.__password.get();
    }
    set password(newValue: string) {
        this.__password.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 10 });
            Column.debugLine("entry/src/main/ets/pages/LoginPage.ets(12:5)", "entry");
            Column.width('90%');
            Column.height(50);
            Column.margin({ top: 20 });
            Column.backgroundImage({ "id": 16777236, "type": 20000, params: [], "bundleName": "com.xxd.jg", "moduleName": "entry" });
            Column.backgroundImageSize(1);
            Column.opacity(1);
            Column.height('100%');
            Column.width('100%');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 10 });
            Row.debugLine("entry/src/main/ets/pages/LoginPage.ets(15:7)", "entry");
            Row.width('28%');
            Row.height(50);
            Row.margin({ top: 100 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777238, "type": 20000, params: [], "bundleName": "com.xxd.jg", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/LoginPage.ets(16:9)", "entry");
            Image.width(100);
            Image.height(100);
            Image.borderRadius(100);
        }, Image);
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/LoginPage.ets(27:7)", "entry");
            Row.width('100%');
            Row.height(50);
            Row.margin({ top: 20 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('phoenix');
            Text.debugLine("entry/src/main/ets/pages/LoginPage.ets(28:9)", "entry");
            Text.fontSize(15);
            Text.width('100%');
            Text.fontColor(Color.Black);
            Text.textAlign(TextAlign.Center);
        }, Text);
        Text.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 10 });
            Row.debugLine("entry/src/main/ets/pages/LoginPage.ets(39:7)", "entry");
            Row.width('90%');
            Row.height(50);
            Row.margin({ top: 40 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('账号：');
            Text.debugLine("entry/src/main/ets/pages/LoginPage.ets(40:9)", "entry");
            Text.fontSize(30);
            Text.fontColor('#000000');
            Text.fontWeight(FontWeight.Medium);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            //提示框输入
            TextInput.create({ placeholder: '请输入您的账号', text: this.account });
            TextInput.debugLine("entry/src/main/ets/pages/LoginPage.ets(46:9)", "entry");
            //提示框输入
            TextInput.fontSize('100%');
            //提示框输入
            TextInput.fontColor('#000000');
            //提示框输入
            TextInput.fontWeight(FontWeight.Bolder);
            //提示框输入
            TextInput.borderRadius(0);
            //提示框输入
            TextInput.width('70%');
            //提示框输入
            TextInput.onChange((value: string) => {
                this.account = value;
            });
            //提示框输入
            TextInput.backgroundColor(0xababab);
            //提示框输入
            TextInput.borderRadius(10);
            //提示框输入
            TextInput.opacity(0.5);
        }, TextInput);
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 10 });
            Row.debugLine("entry/src/main/ets/pages/LoginPage.ets(64:7)", "entry");
            Row.width('90%');
            Row.height(50);
            Row.margin({ top: 20 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('密码：');
            Text.debugLine("entry/src/main/ets/pages/LoginPage.ets(65:9)", "entry");
            Text.fontSize(30);
            Text.fontColor('#000000');
            Text.fontWeight(FontWeight.Medium);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: '请输入您的密码', text: this.password });
            TextInput.debugLine("entry/src/main/ets/pages/LoginPage.ets(70:9)", "entry");
            TextInput.fontSize(30);
            TextInput.fontColor(Color.Black);
            TextInput.fontWeight(FontWeight.Bolder);
            TextInput.type(InputType.Password);
            TextInput.borderRadius(0);
            TextInput.width('70%');
            TextInput.onChange((value: string) => {
                this.password = value;
            });
            TextInput.backgroundColor(0xababab);
            TextInput.borderRadius(10);
            TextInput.opacity(0.5);
        }, TextInput);
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/LoginPage.ets(91:7)", "entry");
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('登录');
            Button.debugLine("entry/src/main/ets/pages/LoginPage.ets(93:9)", "entry");
            Button.fontSize(30);
            Button.fontColor(Color.Black);
            Button.fontWeight(FontWeight.Medium);
            Button.type(ButtonType.Normal);
            Button.borderRadius(5);
            Button.margin({ left: '15%', top: 50 });
            Button.onClick(() => {
                if (this.account == '') {
                    this.showDialog('账号不能为空');
                }
                else if (this.password == '') {
                    this.showDialog('密码不能为空');
                }
                //密码设置
                else if (this.account == 'yangjiayu' && this.password == '666666') {
                    router.push({
                        url: "pages/MainPage" //通过url指定新打开的页面
                    });
                }
                else {
                    this.showDialog('用户名或密码不正确');
                }
            });
        }, Button);
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('重置');
            Button.debugLine("entry/src/main/ets/pages/LoginPage.ets(122:9)", "entry");
            Button.fontSize(30);
            Button.fontColor(Color.Black);
            Button.fontWeight(FontWeight.Medium);
            Button.type(ButtonType.Normal);
            Button.borderRadius(5);
            Button.margin({ left: '20%', right: '15%', top: 50 });
            Button.onClick(() => {
                this.account = '';
                this.password = '';
            });
        }, Button);
        Button.pop();
        Row.pop();
        Column.pop();
    }
    private showDialog(msg: string) {
        promptAction.showDialog({
            title: "提示",
            message: msg,
            buttons: [
                {
                    text: "确定",
                    color: "#000000"
                }
            ]
        }, (error, index) => {
            // let msg = error ? JSON.stringify(error) : "index: " + index;
            // promptAction.showToast({
            //   message: msg
            // })
        });
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "LoginPage";
    }
}
registerNamedRoute(() => new LoginPage(undefined, {}), "", { bundleName: "com.xxd.jg", moduleName: "entry", pagePath: "pages/LoginPage", pageFullPath: "entry/src/main/ets/pages/LoginPage", integratedHsp: "false" });
