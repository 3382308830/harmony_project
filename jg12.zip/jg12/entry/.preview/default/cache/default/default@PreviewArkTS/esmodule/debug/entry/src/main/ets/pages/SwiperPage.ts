if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface SwiperPage_Params {
    controller?: SwiperController;
}
import promptAction from "@ohos:promptAction";
class SwiperPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.controller = new SwiperController();
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: SwiperPage_Params) {
        if (params.controller !== undefined) {
            this.controller = params.controller;
        }
    }
    updateStateVars(params: SwiperPage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private controller: SwiperController;
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/SwiperPage.ets(9:5)", "entry");
            Column.padding(10);
            Column.height('100%');
            Column.width('100%');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Swiper.create(this.controller);
            Swiper.debugLine("entry/src/main/ets/pages/SwiperPage.ets(10:7)", "entry");
            Swiper.width('100%');
            Swiper.height('80%');
            Swiper.onChange((index) => {
                if (index == 0) {
                    promptAction.showToast({
                        message: "章若楠"
                    });
                }
                else if (index == 1) {
                    promptAction.showToast({
                        message: "小姐姐"
                    });
                }
                else if (index == 2) {
                    promptAction.showToast({
                        message: "小姐姐"
                    });
                }
                else if (index == 3) {
                    promptAction.showToast({
                        message: "小姐姐"
                    });
                }
            });
        }, Swiper);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777233, "type": 20000, params: [], "bundleName": "com.xxd.jg", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/SwiperPage.ets(11:9)", "entry");
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777235, "type": 20000, params: [], "bundleName": "com.xxd.jg", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/SwiperPage.ets(12:9)", "entry");
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777234, "type": 20000, params: [], "bundleName": "com.xxd.jg", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/SwiperPage.ets(13:9)", "entry");
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777230, "type": 20000, params: [], "bundleName": "com.xxd.jg", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/SwiperPage.ets(14:9)", "entry");
        }, Image);
        Swiper.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/SwiperPage.ets(42:7)", "entry");
            Row.width('60%');
            Row.margin({ top: 20 });
            Row.justifyContent(FlexAlign.SpaceEvenly);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('上一页');
            Button.debugLine("entry/src/main/ets/pages/SwiperPage.ets(43:9)", "entry");
            Button.type(ButtonType.Normal);
            Button.borderRadius(6);
            Button.onClick(() => {
                this.controller.showPrevious();
            });
        }, Button);
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('下一页');
            Button.debugLine("entry/src/main/ets/pages/SwiperPage.ets(50:9)", "entry");
            Button.type(ButtonType.Normal);
            Button.borderRadius(6);
            Button.onClick(() => {
                this.controller.showNext();
            });
        }, Button);
        Button.pop();
        Row.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "SwiperPage";
    }
}
registerNamedRoute(() => new SwiperPage(undefined, {}), "", { bundleName: "com.xxd.jg", moduleName: "entry", pagePath: "pages/SwiperPage", pageFullPath: "entry/src/main/ets/pages/SwiperPage", integratedHsp: "false" });
