if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface RatingPage_Params {
    score?: number;
}
class RatingPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__score = new ObservedPropertySimplePU(0, this, "score");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: RatingPage_Params) {
        if (params.score !== undefined) {
            this.score = params.score;
        }
    }
    updateStateVars(params: RatingPage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__score.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__score.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __score: ObservedPropertySimplePU<number>;
    get score() {
        return this.__score.get();
    }
    set score(newValue: number) {
        this.__score.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 20 });
            Column.debugLine("entry/src/main/ets/pages/RatingPage.ets(7:5)", "entry");
            Column.height('100%');
            Column.width('100%');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Rating.create({ rating: 3, indicator: true });
            Rating.debugLine("entry/src/main/ets/pages/RatingPage.ets(8:7)", "entry");
            Rating.width(300);
            Rating.height(50);
        }, Rating);
        Rating.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Rating.create({ rating: 3, indicator: false });
            Rating.debugLine("entry/src/main/ets/pages/RatingPage.ets(12:7)", "entry");
            Rating.width(300);
            Rating.height(50);
            Rating.stars(5);
            Rating.stepSize(0.5);
            Rating.onChange((value) => {
                this.score = value;
            });
        }, Rating);
        Rating.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/RatingPage.ets(20:7)", "entry");
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('评分值：');
            Text.debugLine("entry/src/main/ets/pages/RatingPage.ets(21:9)", "entry");
            Text.fontSize(32);
            Text.fontWeight(FontWeight.Medium);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.score.toString());
            Text.debugLine("entry/src/main/ets/pages/RatingPage.ets(24:9)", "entry");
            Text.fontSize(32);
            Text.fontWeight(FontWeight.Medium);
            Text.fontColor("#ff0000");
        }, Text);
        Text.pop();
        Row.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "RatingPage";
    }
}
registerNamedRoute(() => new RatingPage(undefined, {}), "", { bundleName: "com.xxd.jg", moduleName: "entry", pagePath: "pages/RatingPage", pageFullPath: "entry/src/main/ets/pages/RatingPage", integratedHsp: "false" });
