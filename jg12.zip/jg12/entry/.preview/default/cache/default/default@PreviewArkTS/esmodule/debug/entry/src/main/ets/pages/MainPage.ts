if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface MainPage_Params {
}
import router from "@ohos:router";
class routerParams {
    name: string = '';
    constructor(str: string) {
        this.name = str;
    }
}
class MainPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: MainPage_Params) {
    }
    updateStateVars(params: MainPage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Scroll.create();
            Scroll.debugLine("entry/src/main/ets/pages/MainPage.ets(14:5)", "entry");
            Scroll.height('100%');
            Scroll.width('100%');
            Scroll.scrollable(ScrollDirection.Vertical);
            Scroll.scrollBarColor("0xababab");
            Scroll.scrollBarWidth(5);
            Scroll.scrollBar(BarState.On);
            Scroll.backgroundImage({ "id": 16777237, "type": 20000, params: [], "bundleName": "com.xxd.jg", "moduleName": "entry" });
            Scroll.backgroundImageSize(1);
        }, Scroll);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 10 });
            Column.debugLine("entry/src/main/ets/pages/MainPage.ets(15:7)", "entry");
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            //按钮1
            Button.createWithLabel('计数器');
            Button.debugLine("entry/src/main/ets/pages/MainPage.ets(17:9)", "entry");
            //按钮1
            Button.fontSize(30);
            //按钮1
            Button.fontColor(Color.Black);
            //按钮1
            Button.fontWeight(FontWeight.Medium);
            //按钮1
            Button.backgroundColor(0x969696);
            //按钮1
            Button.opacity(0.7);
            //按钮1
            Button.type(ButtonType.Normal);
            //按钮1
            Button.borderRadius(9);
            //按钮1
            Button.borderWidth(0);
            //按钮1
            Button.borderColor(0xff0000);
            //按钮1
            Button.width('40%');
            //按钮1
            Button.height(50);
            //按钮1
            Button.margin({ top: 30 });
            //按钮1
            Button.onClick(() => {
                router.push({
                    url: "pages/Index" // 通过url指定新打开的页面
                });
            });
        }, Button);
        //按钮1
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            //按钮2
            Button.createWithLabel('返回登录窗口');
            Button.debugLine("entry/src/main/ets/pages/MainPage.ets(37:9)", "entry");
            //按钮2
            Button.fontSize(30);
            //按钮2
            Button.fontColor(Color.Black);
            //按钮2
            Button.fontWeight(FontWeight.Medium);
            //按钮2
            Button.backgroundColor(0x969696);
            //按钮2
            Button.opacity(0.7);
            //按钮2
            Button.type(ButtonType.Normal);
            //按钮2
            Button.borderRadius(9);
            //按钮2
            Button.width('60%');
            //按钮2
            Button.height(50);
            //按钮2
            Button.margin({ top: 0 });
            //按钮2
            Button.onClick(() => {
                router.back({ url: 'pages/LoginPage', params: { result: '登录成功' } });
            });
        }, Button);
        //按钮2
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // Button('圆')
            //   .type(ButtonType.Circle)
            //   .fontSize(50)
            //   .fontWeight(900)
            //   .backgroundColor(Color.Pink)
            //   .width(80)
            //   .height(80)
            //按钮3
            Button.createWithChild();
            Button.debugLine("entry/src/main/ets/pages/MainPage.ets(61:9)", "entry");
            // Button('圆')
            //   .type(ButtonType.Circle)
            //   .fontSize(50)
            //   .fontWeight(900)
            //   .backgroundColor(Color.Pink)
            //   .width(80)
            //   .height(80)
            //按钮3
            Button.type(ButtonType.Normal);
            // Button('圆')
            //   .type(ButtonType.Circle)
            //   .fontSize(50)
            //   .fontWeight(900)
            //   .backgroundColor(Color.Pink)
            //   .width(80)
            //   .height(80)
            //按钮3
            Button.borderRadius(9);
            // Button('圆')
            //   .type(ButtonType.Circle)
            //   .fontSize(50)
            //   .fontWeight(900)
            //   .backgroundColor(Color.Pink)
            //   .width(80)
            //   .height(80)
            //按钮3
            Button.backgroundColor(0x969696);
            // Button('圆')
            //   .type(ButtonType.Circle)
            //   .fontSize(50)
            //   .fontWeight(900)
            //   .backgroundColor(Color.Pink)
            //   .width(80)
            //   .height(80)
            //按钮3
            Button.opacity(0.7);
            // Button('圆')
            //   .type(ButtonType.Circle)
            //   .fontSize(50)
            //   .fontWeight(900)
            //   .backgroundColor(Color.Pink)
            //   .width(80)
            //   .height(80)
            //按钮3
            Button.width('40%');
            // Button('圆')
            //   .type(ButtonType.Circle)
            //   .fontSize(50)
            //   .fontWeight(900)
            //   .backgroundColor(Color.Pink)
            //   .width(80)
            //   .height(80)
            //按钮3
            Button.margin({ top: 0 });
            // Button('圆')
            //   .type(ButtonType.Circle)
            //   .fontSize(50)
            //   .fontWeight(900)
            //   .backgroundColor(Color.Pink)
            //   .width(80)
            //   .height(80)
            //按钮3
            Button.height(50);
            // Button('圆')
            //   .type(ButtonType.Circle)
            //   .fontSize(50)
            //   .fontWeight(900)
            //   .backgroundColor(Color.Pink)
            //   .width(80)
            //   .height(80)
            //按钮3
            Button.onClick(() => {
                router.push({
                    url: "pages/ProgressPage"
                });
            });
        }, Button);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('进度条');
            Text.debugLine("entry/src/main/ets/pages/MainPage.ets(62:11)", "entry");
            Text.fontSize(30);
            Text.fontColor('#000000');
            Text.fontWeight(FontWeight.Medium);
        }, Text);
        Text.pop();
        // Button('圆')
        //   .type(ButtonType.Circle)
        //   .fontSize(50)
        //   .fontWeight(900)
        //   .backgroundColor(Color.Pink)
        //   .width(80)
        //   .height(80)
        //按钮3
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            //按钮4
            Button.createWithChild();
            Button.debugLine("entry/src/main/ets/pages/MainPage.ets(82:9)", "entry");
            //按钮4
            Button.backgroundColor("#ffffff");
            //按钮4
            Button.opacity(0.7);
            //按钮4
            Button.width(80);
            //按钮4
            Button.height(80);
            //按钮4
            Button.onClick(() => {
                router.push({
                    url: "pages/yaoPage"
                });
            });
        }, Button);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777229, "type": 20000, params: [], "bundleName": "com.xxd.jg", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/MainPage.ets(83:11)", "entry");
            Image.width(80);
            Image.height(80);
            Image.borderRadius(100);
        }, Image);
        //按钮4
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            //按钮5
            Button.createWithLabel('参数传递');
            Button.debugLine("entry/src/main/ets/pages/MainPage.ets(99:9)", "entry");
            //按钮5
            Button.type(ButtonType.Normal);
            //按钮5
            Button.borderRadius(6);
            //按钮5
            Button.borderColor(0xff0000);
            //按钮5
            Button.borderWidth(0);
            //按钮5
            Button.backgroundColor(0x969696);
            //按钮5
            Button.opacity(0.7);
            //按钮5
            Button.fontSize(30);
            //按钮5
            Button.fontColor(0x000000);
            //按钮5
            Button.fontWeight(FontWeight.Medium);
            //按钮5
            Button.margin({ top: 0 });
            //按钮5
            Button.width('50%');
            //按钮5
            Button.height(50);
            //按钮5
            Button.onClick(() => {
                router.push({
                    url: "pages/FirstPage" // 通过url指定新打开的页面
                });
            });
        }, Button);
        //按钮5
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            //按钮6
            Button.createWithChild();
            Button.debugLine("entry/src/main/ets/pages/MainPage.ets(119:9)", "entry");
            //按钮6
            Button.type(ButtonType.Normal);
            //按钮6
            Button.borderRadius(9);
            //按钮6
            Button.backgroundColor(0x969696);
            //按钮6
            Button.opacity(0.7);
            //按钮6
            Button.width('50%');
            //按钮6
            Button.margin({ top: 0 });
            //按钮6
            Button.height(50);
            //按钮6
            Button.onClick(() => {
                router.push({
                    url: "pages/ImagePage"
                });
            });
        }, Button);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('条件渲染');
            Text.debugLine("entry/src/main/ets/pages/MainPage.ets(120:11)", "entry");
            Text.fontSize(30);
            Text.fontColor('#000000');
            Text.fontWeight(FontWeight.Medium);
        }, Text);
        Text.pop();
        //按钮6
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            //按钮7
            Button.createWithChild();
            Button.debugLine("entry/src/main/ets/pages/MainPage.ets(139:9)", "entry");
            //按钮7
            Button.type(ButtonType.Normal);
            //按钮7
            Button.borderRadius(9);
            //按钮7
            Button.backgroundColor(0x969696);
            //按钮7
            Button.opacity(0.7);
            //按钮7
            Button.width('50%');
            //按钮7
            Button.margin({ top: 0 });
            //按钮7
            Button.height(50);
            //按钮7
            Button.onClick(() => {
                router.push({
                    url: "pages/ForEachPage"
                });
            });
        }, Button);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('循环渲染');
            Text.debugLine("entry/src/main/ets/pages/MainPage.ets(140:11)", "entry");
            Text.fontSize(30);
            Text.fontColor('#000000');
            Text.fontWeight(FontWeight.Medium);
        }, Text);
        Text.pop();
        //按钮7
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            //按钮8
            Button.createWithChild();
            Button.debugLine("entry/src/main/ets/pages/MainPage.ets(159:9)", "entry");
            //按钮8
            Button.type(ButtonType.Normal);
            //按钮8
            Button.borderRadius(9);
            //按钮8
            Button.backgroundColor(0x969696);
            //按钮8
            Button.opacity(0.7);
            //按钮8
            Button.width('50%');
            //按钮8
            Button.margin({ top: 0 });
            //按钮8
            Button.height(50);
            //按钮8
            Button.onClick(() => {
                router.push({
                    url: "pages/ListPage"
                });
            });
        }, Button);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('列表组件');
            Text.debugLine("entry/src/main/ets/pages/MainPage.ets(160:11)", "entry");
            Text.fontSize(30);
            Text.fontColor('#000000');
            Text.fontWeight(FontWeight.Medium);
        }, Text);
        Text.pop();
        //按钮8
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            //按钮9
            Button.createWithChild();
            Button.debugLine("entry/src/main/ets/pages/MainPage.ets(179:9)", "entry");
            //按钮9
            Button.type(ButtonType.Normal);
            //按钮9
            Button.borderRadius(9);
            //按钮9
            Button.backgroundColor(0x969696);
            //按钮9
            Button.opacity(0.7);
            //按钮9
            Button.width('50%');
            //按钮9
            Button.margin({ top: 0 });
            //按钮9
            Button.height(50);
            //按钮9
            Button.onClick(() => {
                router.push({
                    //使用push入找一个新页面
                    url: "pages/PickerPage"
                });
            });
        }, Button);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('选择器');
            Text.debugLine("entry/src/main/ets/pages/MainPage.ets(180:11)", "entry");
            Text.fontSize(30);
            Text.fontColor('#000000');
            Text.fontWeight(FontWeight.Medium);
        }, Text);
        Text.pop();
        //按钮9
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            //按钮10
            Button.createWithChild();
            Button.debugLine("entry/src/main/ets/pages/MainPage.ets(200:9)", "entry");
            //按钮10
            Button.type(ButtonType.Normal);
            //按钮10
            Button.borderRadius(9);
            //按钮10
            Button.backgroundColor(0x969696);
            //按钮10
            Button.opacity(0.7);
            //按钮10
            Button.width('50%');
            //按钮10
            Button.margin({ top: 0 });
            //按钮10
            Button.height(50);
            //按钮10
            Button.onClick(() => {
                router.push({
                    //使用push入找一个新页面
                    url: "pages/QRCodePage"
                });
            });
        }, Button);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('二维码');
            Text.debugLine("entry/src/main/ets/pages/MainPage.ets(201:11)", "entry");
            Text.fontSize(30);
            Text.fontColor('#000000');
            Text.fontWeight(FontWeight.Medium);
        }, Text);
        Text.pop();
        //按钮10
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            //按钮11
            Button.createWithChild();
            Button.debugLine("entry/src/main/ets/pages/MainPage.ets(221:9)", "entry");
            //按钮11
            Button.type(ButtonType.Normal);
            //按钮11
            Button.borderRadius(9);
            //按钮11
            Button.backgroundColor(0x969696);
            //按钮11
            Button.opacity(0.7);
            //按钮11
            Button.width('50%');
            //按钮11
            Button.margin({ top: 0 });
            //按钮11
            Button.height(50);
            //按钮11
            Button.onClick(() => {
                router.push({
                    //使用push入找一个新页面
                    url: "pages/TogglePage"
                });
            });
        }, Button);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('开关组件');
            Text.debugLine("entry/src/main/ets/pages/MainPage.ets(222:11)", "entry");
            Text.fontSize(30);
            Text.fontColor('#000000');
            Text.fontWeight(FontWeight.Medium);
        }, Text);
        Text.pop();
        //按钮11
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            //按钮12
            Button.createWithChild();
            Button.debugLine("entry/src/main/ets/pages/MainPage.ets(242:9)", "entry");
            //按钮12
            Button.type(ButtonType.Normal);
            //按钮12
            Button.borderRadius(9);
            //按钮12
            Button.backgroundColor(0x969696);
            //按钮12
            Button.opacity(0.7);
            //按钮12
            Button.width('50%');
            //按钮12
            Button.margin({ top: 0 });
            //按钮12
            Button.height(50);
            //按钮12
            Button.onClick(() => {
                router.push({
                    url: "pages/SilderPage"
                });
            });
        }, Button);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('滑动条组件');
            Text.debugLine("entry/src/main/ets/pages/MainPage.ets(243:11)", "entry");
            Text.fontSize(30);
            Text.fontColor('#000000');
            Text.fontWeight(FontWeight.Medium);
        }, Text);
        Text.pop();
        //按钮12
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            //按钮13
            Button.createWithChild();
            Button.debugLine("entry/src/main/ets/pages/MainPage.ets(262:9)", "entry");
            //按钮13
            Button.type(ButtonType.Normal);
            //按钮13
            Button.borderRadius(9);
            //按钮13
            Button.backgroundColor(0x969696);
            //按钮13
            Button.opacity(0.7);
            //按钮13
            Button.width('50%');
            //按钮13
            Button.margin({ top: 0 });
            //按钮13
            Button.height(50);
            //按钮13
            Button.onClick(() => {
                router.push({
                    //使用push入找一个新页面
                    url: "pages/FlexPage"
                });
            });
        }, Button);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('弹性布局');
            Text.debugLine("entry/src/main/ets/pages/MainPage.ets(263:11)", "entry");
            Text.fontSize(30);
            Text.fontColor('#000000');
            Text.fontWeight(FontWeight.Medium);
        }, Text);
        Text.pop();
        //按钮13
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            //按钮14
            Button.createWithChild();
            Button.debugLine("entry/src/main/ets/pages/MainPage.ets(283:9)", "entry");
            //按钮14
            Button.type(ButtonType.Normal);
            //按钮14
            Button.borderRadius(9);
            //按钮14
            Button.backgroundColor(0x969696);
            //按钮14
            Button.opacity(0.7);
            //按钮14
            Button.width('50%');
            //按钮14
            Button.margin({ top: 0 });
            //按钮14
            Button.height(50);
            //按钮14
            Button.onClick(() => {
                router.push({
                    //使用push入找一个新页面
                    url: "pages/RelativePage"
                });
            });
        }, Button);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('相对布局');
            Text.debugLine("entry/src/main/ets/pages/MainPage.ets(284:11)", "entry");
            Text.fontSize(30);
            Text.fontColor('#000000');
            Text.fontWeight(FontWeight.Medium);
        }, Text);
        Text.pop();
        //按钮14
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            //按钮15
            Button.createWithChild();
            Button.debugLine("entry/src/main/ets/pages/MainPage.ets(304:9)", "entry");
            //按钮15
            Button.type(ButtonType.Normal);
            //按钮15
            Button.borderRadius(9);
            //按钮15
            Button.backgroundColor(0x969696);
            //按钮15
            Button.opacity(0.7);
            //按钮15
            Button.width('50%');
            //按钮15
            Button.margin({ top: 0 });
            //按钮15
            Button.height(50);
            //按钮15
            Button.onClick(() => {
                router.push({
                    //使用push入找一个新页面
                    url: "pages/LinearPage"
                });
            });
        }, Button);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('线性布局');
            Text.debugLine("entry/src/main/ets/pages/MainPage.ets(305:11)", "entry");
            Text.fontSize(30);
            Text.fontColor('#000000');
            Text.fontWeight(FontWeight.Medium);
        }, Text);
        Text.pop();
        //按钮15
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            //按钮16
            Button.createWithChild();
            Button.debugLine("entry/src/main/ets/pages/MainPage.ets(325:9)", "entry");
            //按钮16
            Button.type(ButtonType.Normal);
            //按钮16
            Button.borderRadius(9);
            //按钮16
            Button.backgroundColor(0x969696);
            //按钮16
            Button.opacity(0.7);
            //按钮16
            Button.width('50%');
            //按钮16
            Button.margin({ top: 0 });
            //按钮16
            Button.height(50);
            //按钮16
            Button.onClick(() => {
                router.push({
                    //使用push入找一个新页面
                    url: "pages/SideBarPage"
                });
            });
        }, Button);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('侧边栏');
            Text.debugLine("entry/src/main/ets/pages/MainPage.ets(326:11)", "entry");
            Text.fontSize(30);
            Text.fontColor('#000000');
            Text.fontWeight(FontWeight.Medium);
        }, Text);
        Text.pop();
        //按钮16
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            //按钮17
            Button.createWithChild();
            Button.debugLine("entry/src/main/ets/pages/MainPage.ets(346:9)", "entry");
            //按钮17
            Button.type(ButtonType.Normal);
            //按钮17
            Button.borderRadius(9);
            //按钮17
            Button.backgroundColor(0x969696);
            //按钮17
            Button.opacity(0.7);
            //按钮17
            Button.width('50%');
            //按钮17
            Button.margin({ top: 0 });
            //按钮17
            Button.height(50);
            //按钮17
            Button.onClick(() => {
                router.push({
                    //使用push入找一个新页面
                    url: "pages/SwiperPage"
                });
            });
        }, Button);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('轮播图');
            Text.debugLine("entry/src/main/ets/pages/MainPage.ets(347:11)", "entry");
            Text.fontSize(30);
            Text.fontColor('#000000');
            Text.fontWeight(FontWeight.Medium);
        }, Text);
        Text.pop();
        //按钮17
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            //按钮18
            Button.createWithChild();
            Button.debugLine("entry/src/main/ets/pages/MainPage.ets(367:9)", "entry");
            //按钮18
            Button.type(ButtonType.Normal);
            //按钮18
            Button.borderRadius(9);
            //按钮18
            Button.backgroundColor(0x969696);
            //按钮18
            Button.opacity(0.7);
            //按钮18
            Button.width('50%');
            //按钮18
            Button.margin({ top: 0 });
            //按钮18
            Button.height(50);
            //按钮18
            Button.onClick(() => {
                router.push({
                    //使用push入找一个新页面
                    url: "pages/TabsPage"
                });
            });
        }, Button);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('页签');
            Text.debugLine("entry/src/main/ets/pages/MainPage.ets(368:11)", "entry");
            Text.fontSize(30);
            Text.fontColor('#000000');
            Text.fontWeight(FontWeight.Medium);
        }, Text);
        Text.pop();
        //按钮18
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            //按钮19
            Button.createWithChild();
            Button.debugLine("entry/src/main/ets/pages/MainPage.ets(388:9)", "entry");
            //按钮19
            Button.type(ButtonType.Normal);
            //按钮19
            Button.borderRadius(9);
            //按钮19
            Button.backgroundColor(0x969696);
            //按钮19
            Button.opacity(0.7);
            //按钮19
            Button.width('50%');
            //按钮19
            Button.margin({ top: 0 });
            //按钮19
            Button.height(50);
            //按钮19
            Button.onClick(() => {
                router.push({
                    //使用push入找一个新页面
                    url: "pages/RatingPage"
                });
            });
        }, Button);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('评分条');
            Text.debugLine("entry/src/main/ets/pages/MainPage.ets(389:11)", "entry");
            Text.fontSize(30);
            Text.fontColor('#000000');
            Text.fontWeight(FontWeight.Medium);
        }, Text);
        Text.pop();
        //按钮19
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            //按钮20
            Button.createWithChild();
            Button.debugLine("entry/src/main/ets/pages/MainPage.ets(409:9)", "entry");
            //按钮20
            Button.type(ButtonType.Normal);
            //按钮20
            Button.borderRadius(9);
            //按钮20
            Button.backgroundColor(0x969696);
            //按钮20
            Button.opacity(0.7);
            //按钮20
            Button.width('50%');
            //按钮20
            Button.margin({ top: 0 });
            //按钮20
            Button.height(50);
            //按钮20
            Button.onClick(() => {
                router.push({
                    //使用push入找一个新页面
                    url: "pages/CounterPage"
                });
            });
        }, Button);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('计数器');
            Text.debugLine("entry/src/main/ets/pages/MainPage.ets(410:11)", "entry");
            Text.fontSize(30);
            Text.fontColor('#000000');
            Text.fontWeight(FontWeight.Medium);
        }, Text);
        Text.pop();
        //按钮20
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            //按钮21
            Button.createWithChild();
            Button.debugLine("entry/src/main/ets/pages/MainPage.ets(430:9)", "entry");
            //按钮21
            Button.type(ButtonType.Normal);
            //按钮21
            Button.borderRadius(9);
            //按钮21
            Button.backgroundColor(0x969696);
            //按钮21
            Button.opacity(0.7);
            //按钮21
            Button.width('40%');
            //按钮21
            Button.margin({ top: 0 });
            //按钮21
            Button.height(50);
            //按钮21
            Button.onClick(() => {
                router.push({
                    //使用push入找一个新页面
                    url: "pages/BadgePage"
                });
            });
        }, Button);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('角标');
            Text.debugLine("entry/src/main/ets/pages/MainPage.ets(431:11)", "entry");
            Text.fontSize(30);
            Text.fontColor('#000000');
            Text.fontWeight(FontWeight.Medium);
        }, Text);
        Text.pop();
        //按钮21
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            //按钮22
            Button.createWithChild();
            Button.debugLine("entry/src/main/ets/pages/MainPage.ets(451:9)", "entry");
            //按钮22
            Button.type(ButtonType.Normal);
            //按钮22
            Button.borderRadius(9);
            //按钮22
            Button.backgroundColor(0x969696);
            //按钮22
            Button.opacity(0.7);
            //按钮22
            Button.width('50%');
            //按钮22
            Button.margin({ top: 0 });
            //按钮22
            Button.height(50);
            //按钮22
            Button.onClick(() => {
                router.push({
                    //使用push入找一个新页面
                    url: "pages/GridComponmentPage"
                });
            });
        }, Button);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('表格组件');
            Text.debugLine("entry/src/main/ets/pages/MainPage.ets(452:11)", "entry");
            Text.fontSize(30);
            Text.fontColor('#000000');
            Text.fontWeight(FontWeight.Medium);
        }, Text);
        Text.pop();
        //按钮22
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            //按钮23
            Button.createWithChild();
            Button.debugLine("entry/src/main/ets/pages/MainPage.ets(472:9)", "entry");
            //按钮23
            Button.type(ButtonType.Normal);
            //按钮23
            Button.borderRadius(9);
            //按钮23
            Button.backgroundColor(0x969696);
            //按钮23
            Button.opacity(0.7);
            //按钮23
            Button.width('60%');
            //按钮23
            Button.margin({ top: 0 });
            //按钮23
            Button.height(50);
            //按钮23
            Button.onClick(() => {
                router.push({
                    //使用push入找一个新页面
                    url: "pages/FindStudentPage"
                });
            });
        }, Button);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('查询学生姓名');
            Text.debugLine("entry/src/main/ets/pages/MainPage.ets(473:11)", "entry");
            Text.fontSize(30);
            Text.fontColor('#000000');
            Text.fontWeight(FontWeight.Medium);
        }, Text);
        Text.pop();
        //按钮23
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            //按钮24
            Button.createWithChild();
            Button.debugLine("entry/src/main/ets/pages/MainPage.ets(493:9)", "entry");
            //按钮24
            Button.type(ButtonType.Normal);
            //按钮24
            Button.borderRadius(9);
            //按钮24
            Button.backgroundColor(0x969696);
            //按钮24
            Button.opacity(0.7);
            //按钮24
            Button.width('80%');
            //按钮24
            Button.margin({ top: 0 });
            //按钮24
            Button.height(50);
            //按钮24
            Button.onClick(() => {
                router.push({
                    //使用push入找一个新页面
                    url: "pages/ListRenderPage"
                });
            });
        }, Button);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('动态渲染列表数据');
            Text.debugLine("entry/src/main/ets/pages/MainPage.ets(494:11)", "entry");
            Text.fontSize(30);
            Text.fontColor('#000000');
            Text.fontWeight(FontWeight.Medium);
        }, Text);
        Text.pop();
        //按钮24
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            //按钮25
            Button.createWithChild();
            Button.debugLine("entry/src/main/ets/pages/MainPage.ets(515:9)", "entry");
            //按钮25
            Button.type(ButtonType.Normal);
            //按钮25
            Button.borderRadius(9);
            //按钮25
            Button.backgroundColor(0x969696);
            //按钮25
            Button.opacity(0.7);
            //按钮25
            Button.width('80%');
            //按钮25
            Button.margin({ top: 0 });
            //按钮25
            Button.height(50);
            //按钮25
            Button.onClick(() => {
                router.push({
                    //使用push入找一个新页面
                    url: "pages/GridRenderPage"
                });
            });
        }, Button);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('动态渲染表格数据');
            Text.debugLine("entry/src/main/ets/pages/MainPage.ets(516:11)", "entry");
            Text.fontSize(30);
            Text.fontColor('#000000');
            Text.fontWeight(FontWeight.Medium);
        }, Text);
        Text.pop();
        //按钮25
        Button.pop();
        Column.pop();
        Scroll.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "MainPage";
    }
}
registerNamedRoute(() => new MainPage(undefined, {}), "", { bundleName: "com.xxd.jg", moduleName: "entry", pagePath: "pages/MainPage", pageFullPath: "entry/src/main/ets/pages/MainPage", integratedHsp: "false" });
