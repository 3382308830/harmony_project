if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface GridRenderPage_Params {
    message?: string;
    stus?: Student[];
}
import http from "@ohos:net.http";
import type { Student } from '../class/Student';
import promptAction from "@ohos:promptAction";
class GridRenderPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__message = new ObservedPropertySimplePU('西信大学生', this, "message");
        this.__stus = new ObservedPropertyObjectPU([], this, "stus");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: GridRenderPage_Params) {
        if (params.message !== undefined) {
            this.message = params.message;
        }
        if (params.stus !== undefined) {
            this.stus = params.stus;
        }
    }
    updateStateVars(params: GridRenderPage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__message.purgeDependencyOnElmtId(rmElmtId);
        this.__stus.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__message.aboutToBeDeleted();
        this.__stus.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __message: ObservedPropertySimplePU<string>;
    get message() {
        return this.__message.get();
    }
    set message(newValue: string) {
        this.__message.set(newValue);
    }
    private __stus: ObservedPropertyObjectPU<Student[]>;
    get stus() {
        return this.__stus.get();
    }
    set stus(newValue: Student[]) {
        this.__stus.set(newValue);
    }
    async aboutToAppear() {
        this.stus = await findAllStus();
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/GridRenderPage.ets(214:5)", "entry");
            Column.padding(10);
            Column.height('100%');
            Column.width('100%');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.message);
            Text.debugLine("entry/src/main/ets/pages/GridRenderPage.ets(215:7)", "entry");
            Text.id('GridRenderHelloWorld');
            Text.fontSize(40);
            Text.fontWeight(FontWeight.Bold);
            Text.margin({ top: 10 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Grid.create();
            Grid.debugLine("entry/src/main/ets/pages/GridRenderPage.ets(222:7)", "entry");
            Grid.columnsTemplate("1fr 1fr 1fr 3fr");
            Grid.columnsGap(0);
            Grid.rowsGap(0);
            Grid.width('100%');
            Grid.height(40);
        }, Grid);
        {
            const itemCreation2 = (elmtId, isInitialRender) => {
                GridItem.create(() => { }, false);
                GridItem.borderWidth(1);
                GridItem.borderColor("#000000");
                GridItem.backgroundColor("#aabbcc");
                GridItem.debugLine("entry/src/main/ets/pages/GridRenderPage.ets(223:9)", "entry");
            };
            const observedDeepRender = () => {
                this.observeComponentCreation2(itemCreation2, GridItem);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create('学号');
                    Text.debugLine("entry/src/main/ets/pages/GridRenderPage.ets(224:11)", "entry");
                    Text.width('100%');
                    Text.height(40);
                    Text.fontSize(18);
                    Text.fontWeight(FontWeight.Bold);
                    Text.textAlign(TextAlign.Center);
                }, Text);
                Text.pop();
                GridItem.pop();
            };
            observedDeepRender();
        }
        {
            const itemCreation2 = (elmtId, isInitialRender) => {
                GridItem.create(() => { }, false);
                GridItem.borderWidth(1);
                GridItem.borderColor("#000000");
                GridItem.backgroundColor("#aabbcc");
                GridItem.debugLine("entry/src/main/ets/pages/GridRenderPage.ets(237:9)", "entry");
            };
            const observedDeepRender = () => {
                this.observeComponentCreation2(itemCreation2, GridItem);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create('姓名');
                    Text.debugLine("entry/src/main/ets/pages/GridRenderPage.ets(238:11)", "entry");
                    Text.width('100%');
                    Text.height(40);
                    Text.fontSize(18);
                    Text.fontWeight(FontWeight.Bold);
                    Text.textAlign(TextAlign.Center);
                }, Text);
                Text.pop();
                GridItem.pop();
            };
            observedDeepRender();
        }
        {
            const itemCreation2 = (elmtId, isInitialRender) => {
                GridItem.create(() => { }, false);
                GridItem.borderWidth(1);
                GridItem.borderColor("#000000");
                GridItem.backgroundColor("#aabbcc");
                GridItem.debugLine("entry/src/main/ets/pages/GridRenderPage.ets(252:9)", "entry");
            };
            const observedDeepRender = () => {
                this.observeComponentCreation2(itemCreation2, GridItem);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create('性别');
                    Text.debugLine("entry/src/main/ets/pages/GridRenderPage.ets(253:11)", "entry");
                    Text.width('100%');
                    Text.height(40);
                    Text.fontSize(18);
                    Text.fontWeight(FontWeight.Bold);
                    Text.textAlign(TextAlign.Center);
                }, Text);
                Text.pop();
                GridItem.pop();
            };
            observedDeepRender();
        }
        {
            const itemCreation2 = (elmtId, isInitialRender) => {
                GridItem.create(() => { }, false);
                GridItem.borderWidth(1);
                GridItem.borderColor("#000000");
                GridItem.backgroundColor("#aabbcc");
                GridItem.debugLine("entry/src/main/ets/pages/GridRenderPage.ets(267:9)", "entry");
            };
            const observedDeepRender = () => {
                this.observeComponentCreation2(itemCreation2, GridItem);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create('专业');
                    Text.debugLine("entry/src/main/ets/pages/GridRenderPage.ets(268:11)", "entry");
                    Text.width('100%');
                    Text.height(40);
                    Text.fontSize(18);
                    Text.fontWeight(FontWeight.Bold);
                    Text.textAlign(TextAlign.Center);
                }, Text);
                Text.pop();
                GridItem.pop();
            };
            observedDeepRender();
        }
        Grid.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Grid.create();
            Grid.debugLine("entry/src/main/ets/pages/GridRenderPage.ets(289:7)", "entry");
            Grid.columnsTemplate("1fr 1fr 1fr 3fr");
            Grid.columnsGap(0);
            Grid.rowsGap(0);
            Grid.width('100%');
            Grid.height('90%');
        }, Grid);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = (_item, index: number) => {
                const item = _item;
                {
                    const itemCreation2 = (elmtId, isInitialRender) => {
                        GridItem.create(() => { }, false);
                        GridItem.borderWidth(1);
                        GridItem.borderColor("#000000");
                        GridItem.onClick(() => {
                            promptAction.showDialog({
                                title: `姓名: ${item.name}`,
                                message: `学号: ${item.id} \n姓名: ${item.gender} \n专业: ${item.major}`
                            });
                        });
                        GridItem.debugLine("entry/src/main/ets/pages/GridRenderPage.ets(291:11)", "entry");
                    };
                    const observedDeepRender = () => {
                        this.observeComponentCreation2(itemCreation2, GridItem);
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Text.create(item.id);
                            Text.debugLine("entry/src/main/ets/pages/GridRenderPage.ets(292:13)", "entry");
                            Text.width('100%');
                            Text.height(40);
                            Text.fontSize(18);
                            Text.fontWeight(FontWeight.Bold);
                            Text.textAlign(TextAlign.Center);
                        }, Text);
                        Text.pop();
                        GridItem.pop();
                    };
                    observedDeepRender();
                }
                {
                    const itemCreation2 = (elmtId, isInitialRender) => {
                        GridItem.create(() => { }, false);
                        GridItem.borderWidth(1);
                        GridItem.borderColor("#000000");
                        GridItem.onClick(() => {
                            promptAction.showDialog({
                                title: `姓名: ${item.name}`,
                                message: `学号: ${item.id} \n姓名: ${item.gender} \n专业: ${item.major}`
                            });
                        });
                        GridItem.debugLine("entry/src/main/ets/pages/GridRenderPage.ets(308:11)", "entry");
                    };
                    const observedDeepRender = () => {
                        this.observeComponentCreation2(itemCreation2, GridItem);
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Text.create(item.name);
                            Text.debugLine("entry/src/main/ets/pages/GridRenderPage.ets(309:13)", "entry");
                            Text.width('100%');
                            Text.height(40);
                            Text.fontSize(18);
                            Text.fontWeight(FontWeight.Bold);
                            Text.textAlign(TextAlign.Center);
                        }, Text);
                        Text.pop();
                        GridItem.pop();
                    };
                    observedDeepRender();
                }
                {
                    const itemCreation2 = (elmtId, isInitialRender) => {
                        GridItem.create(() => { }, false);
                        GridItem.borderWidth(1);
                        GridItem.borderColor("#000000");
                        GridItem.onClick(() => {
                            promptAction.showDialog({
                                title: `姓名: ${item.name}`,
                                message: `学号: ${item.id} \n姓名: ${item.gender} \n专业: ${item.major}`
                            });
                        });
                        GridItem.debugLine("entry/src/main/ets/pages/GridRenderPage.ets(325:11)", "entry");
                    };
                    const observedDeepRender = () => {
                        this.observeComponentCreation2(itemCreation2, GridItem);
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Text.create(item.gender);
                            Text.debugLine("entry/src/main/ets/pages/GridRenderPage.ets(326:13)", "entry");
                            Text.width('100%');
                            Text.height(40);
                            Text.fontSize(18);
                            Text.fontWeight(FontWeight.Bold);
                            Text.textAlign(TextAlign.Center);
                        }, Text);
                        Text.pop();
                        GridItem.pop();
                    };
                    observedDeepRender();
                }
                {
                    const itemCreation2 = (elmtId, isInitialRender) => {
                        GridItem.create(() => { }, false);
                        GridItem.borderWidth(1);
                        GridItem.borderColor("#000000");
                        GridItem.onClick(() => {
                            promptAction.showDialog({
                                title: `姓名: ${item.name}`,
                                message: `学号: ${item.id} \n姓名: ${item.gender} \n专业: ${item.major}`
                            });
                        });
                        GridItem.debugLine("entry/src/main/ets/pages/GridRenderPage.ets(343:11)", "entry");
                    };
                    const observedDeepRender = () => {
                        this.observeComponentCreation2(itemCreation2, GridItem);
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Text.create(item.major);
                            Text.debugLine("entry/src/main/ets/pages/GridRenderPage.ets(344:13)", "entry");
                            Text.width('100%');
                            Text.height(40);
                            Text.fontSize(18);
                            Text.fontWeight(FontWeight.Bold);
                            Text.textAlign(TextAlign.Center);
                        }, Text);
                        Text.pop();
                        GridItem.pop();
                    };
                    observedDeepRender();
                }
            };
            this.forEachUpdateFunction(elmtId, this.stus, forEachItemGenFunction, undefined, true, false);
        }, ForEach);
        ForEach.pop();
        Grid.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "GridRenderPage";
    }
}
async function findAllStus(): Promise<Student[]> {
    let students: Student[] = []; //let students:Array<Student> = []
    let httpRequest = http.createHttp();
    let response = httpRequest.request("http://47.115.220.75:8080/hwstus", // 请求的URL
    {
        method: http.RequestMethod.POST,
        header: {
            'Content-Type': 'application/json' // 添加Header，header 默认值就是application/json
        },
        readTimeout: 15000,
        connectTimeout: 15000, // 超时时间
        //extraData: "extra data"                   // 发送请求参数
    });
    await response.then((data) => {
        // 解析json数组
        students = JSON.parse(`${data.result}`);
    });
    return students;
}
registerNamedRoute(() => new GridRenderPage(undefined, {}), "", { bundleName: "com.xxd.jg", moduleName: "entry", pagePath: "pages/GridRenderPage", pageFullPath: "entry/src/main/ets/pages/GridRenderPage", integratedHsp: "false" });
