if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface FlexPage_Params {
}
class FlexPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: FlexPage_Params) {
    }
    updateStateVars(params: FlexPage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/FlexPage.ets(6:5)", "entry");
            Column.padding(10);
            Column.size({ width: "100%", height: '100%' });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('西安信息职业大学校训');
            Text.debugLine("entry/src/main/ets/pages/FlexPage.ets(7:7)", "entry");
            Text.fontSize(30);
            Text.fontColor(Color.Black);
            Text.fontWeight(FontWeight.Bolder);
            Text.margin({ top: 30, bottom: 20 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Flex.create({ direction: FlexDirection.Row, justifyContent: FlexAlign.SpaceAround, alignItems: ItemAlign.Center });
            Flex.debugLine("entry/src/main/ets/pages/FlexPage.ets(13:7)", "entry");
            Flex.width('100%');
            Flex.height(60);
            Flex.backgroundColor(Color.Pink);
        }, Flex);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('厚德');
            Text.debugLine("entry/src/main/ets/pages/FlexPage.ets(14:9)", "entry");
            Text.fontSize(16);
            Text.padding(20);
            Text.backgroundColor("#aabbcc");
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('自强');
            Text.debugLine("entry/src/main/ets/pages/FlexPage.ets(18:9)", "entry");
            Text.fontSize(16);
            Text.padding(20);
            Text.backgroundColor("#bbaacc");
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('创新');
            Text.debugLine("entry/src/main/ets/pages/FlexPage.ets(22:9)", "entry");
            Text.fontSize(16);
            Text.padding(20);
            Text.backgroundColor("#ccaabb");
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('奉献');
            Text.debugLine("entry/src/main/ets/pages/FlexPage.ets(26:9)", "entry");
            Text.fontSize(16);
            Text.padding(20);
            Text.backgroundColor("#abcabc");
        }, Text);
        Text.pop();
        Flex.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "FlexPage";
    }
}
registerNamedRoute(() => new FlexPage(undefined, {}), "", { bundleName: "com.xxd.jg", moduleName: "entry", pagePath: "pages/FlexPage", pageFullPath: "entry/src/main/ets/pages/FlexPage", integratedHsp: "false" });
