if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface TabsPage_Params {
    controller?: TabsController;
    index?: number;
}
class TabsPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.controller = new TabsController();
        this.__index = new ObservedPropertySimplePU(0, this, "index");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: TabsPage_Params) {
        if (params.controller !== undefined) {
            this.controller = params.controller;
        }
        if (params.index !== undefined) {
            this.index = params.index;
        }
    }
    updateStateVars(params: TabsPage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__index.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__index.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private controller: TabsController;
    private __index: ObservedPropertySimplePU<number>;
    get index() {
        return this.__index.get();
    }
    set index(newValue: number) {
        this.__index.set(newValue);
    }
    tabGirl1(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/TabsPage.ets(8:5)", "entry");
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/TabsPage.ets(9:7)", "entry");
            Column.backgroundColor(this.index == 0 ? Color.Pink : Color.Yellow);
            Column.height('100%');
            Column.width("100%");
            Column.onClick(() => {
                this.index = 0;
                this.controller.changeIndex(this.index);
            });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/TabsPage.ets(10:9)", "entry");
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create(this.index == 0 ? { "id": 16777228, "type": 20000, params: [], "bundleName": "com.xxd.jg", "moduleName": "entry" } : { "id": 16777228, "type": 20000, params: [], "bundleName": "com.xxd.jg", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/TabsPage.ets(11:9)", "entry");
            Image.size({ width: 25, height: 25 });
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('章若楠');
            Text.debugLine("entry/src/main/ets/pages/TabsPage.ets(13:9)", "entry");
            Text.fontSize(16);
            Text.fontColor(this.index == 0 ? "#ff0000" : "#0000ff");
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/TabsPage.ets(16:9)", "entry");
        }, Blank);
        Blank.pop();
        Column.pop();
        Column.pop();
    }
    tabGirl2(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/TabsPage.ets(29:5)", "entry");
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/TabsPage.ets(30:7)", "entry");
            Column.backgroundColor(this.index == 1 ? Color.Pink : Color.Yellow);
            Column.height('100%');
            Column.width("100%");
            Column.onClick(() => {
                this.index = 1;
                this.controller.changeIndex(this.index);
            });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/TabsPage.ets(31:9)", "entry");
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create(this.index == 1 ? { "id": 16777228, "type": 20000, params: [], "bundleName": "com.xxd.jg", "moduleName": "entry" } : { "id": 16777228, "type": 20000, params: [], "bundleName": "com.xxd.jg", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/TabsPage.ets(32:9)", "entry");
            Image.size({ width: 25, height: 25 });
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('小姐姐');
            Text.debugLine("entry/src/main/ets/pages/TabsPage.ets(34:9)", "entry");
            Text.fontSize(16);
            Text.fontColor(this.index == 1 ? "#ff0000" : "#0000ff");
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/TabsPage.ets(37:9)", "entry");
        }, Blank);
        Blank.pop();
        Column.pop();
        Column.pop();
    }
    tabGirl3(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/TabsPage.ets(50:5)", "entry");
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/TabsPage.ets(51:7)", "entry");
            Column.backgroundColor(this.index == 2 ? Color.Pink : Color.Yellow);
            Column.height('100%');
            Column.width("100%");
            Column.onClick(() => {
                this.index = 2;
                this.controller.changeIndex(this.index);
            });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/TabsPage.ets(52:9)", "entry");
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create(this.index == 2 ? { "id": 16777228, "type": 20000, params: [], "bundleName": "com.xxd.jg", "moduleName": "entry" } : { "id": 16777228, "type": 20000, params: [], "bundleName": "com.xxd.jg", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/TabsPage.ets(53:9)", "entry");
            Image.size({ width: 25, height: 25 });
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('小姐姐');
            Text.debugLine("entry/src/main/ets/pages/TabsPage.ets(55:9)", "entry");
            Text.fontSize(16);
            Text.fontColor(this.index == 2 ? "#ff0000" : "#0000ff");
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/TabsPage.ets(58:9)", "entry");
        }, Blank);
        Blank.pop();
        Column.pop();
        Column.pop();
    }
    tabGirl4(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/TabsPage.ets(71:5)", "entry");
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/TabsPage.ets(72:7)", "entry");
            Column.backgroundColor(this.index == 2 ? Color.Pink : Color.Yellow);
            Column.height('100%');
            Column.width("100%");
            Column.onClick(() => {
                this.index = 3;
                this.controller.changeIndex(this.index);
            });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/TabsPage.ets(73:9)", "entry");
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create(this.index == 3 ? { "id": 16777228, "type": 20000, params: [], "bundleName": "com.xxd.jg", "moduleName": "entry" } : { "id": 16777228, "type": 20000, params: [], "bundleName": "com.xxd.jg", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/TabsPage.ets(74:9)", "entry");
            Image.size({ width: 25, height: 25 });
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('小姐姐');
            Text.debugLine("entry/src/main/ets/pages/TabsPage.ets(76:9)", "entry");
            Text.fontSize(16);
            Text.fontColor(this.index == 3 ? "#ff0000" : "#0000ff");
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/TabsPage.ets(79:9)", "entry");
        }, Blank);
        Blank.pop();
        Column.pop();
        Column.pop();
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/TabsPage.ets(92:5)", "entry");
            Column.padding(10);
            Column.height('100%');
            Column.width('100%');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Tabs.create({
                barPosition: BarPosition.End,
                controller: this.controller
            });
            Tabs.debugLine("entry/src/main/ets/pages/TabsPage.ets(93:7)", "entry");
            Tabs.width('100%');
            Tabs.height('100%');
            Tabs.vertical(false);
            Tabs.scrollable(true);
            Tabs.onChange((index) => {
                this.index = index;
            });
        }, Tabs);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TabContent.create(() => {
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Image.create({ "id": 16777233, "type": 20000, params: [], "bundleName": "com.xxd.jg", "moduleName": "entry" });
                    Image.debugLine("entry/src/main/ets/pages/TabsPage.ets(98:11)", "entry");
                    Image.width('100%');
                    Image.height('100%');
                    Image.backgroundColor("#aabbcc");
                }, Image);
            });
            TabContent.width('100%');
            TabContent.height('100%');
            TabContent.tabBar({ builder: () => {
                    this.tabGirl1.call(this);
                } });
            TabContent.debugLine("entry/src/main/ets/pages/TabsPage.ets(97:9)", "entry");
        }, TabContent);
        TabContent.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TabContent.create(() => {
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Image.create({ "id": 16777235, "type": 20000, params: [], "bundleName": "com.xxd.jg", "moduleName": "entry" });
                    Image.debugLine("entry/src/main/ets/pages/TabsPage.ets(108:11)", "entry");
                    Image.width('100%');
                    Image.height('100%');
                    Image.backgroundColor("#bbccaa");
                }, Image);
            });
            TabContent.width('100%');
            TabContent.height('100%');
            TabContent.tabBar({ builder: () => {
                    this.tabGirl2.call(this);
                } });
            TabContent.debugLine("entry/src/main/ets/pages/TabsPage.ets(107:9)", "entry");
        }, TabContent);
        TabContent.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TabContent.create(() => {
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Image.create({ "id": 16777234, "type": 20000, params: [], "bundleName": "com.xxd.jg", "moduleName": "entry" });
                    Image.debugLine("entry/src/main/ets/pages/TabsPage.ets(118:11)", "entry");
                    Image.width('100%');
                    Image.height('100%');
                    Image.backgroundColor("#aabbcc");
                }, Image);
            });
            TabContent.width('100%');
            TabContent.height('100%');
            TabContent.tabBar({ builder: () => {
                    this.tabGirl3.call(this);
                } });
            TabContent.debugLine("entry/src/main/ets/pages/TabsPage.ets(117:9)", "entry");
        }, TabContent);
        TabContent.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TabContent.create(() => {
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Image.create({ "id": -1, "type": -1, params: ["app.media.girl4" +
                                ""], "bundleName": "com.xxd.jg", "moduleName": "entry" });
                    Image.debugLine("entry/src/main/ets/pages/TabsPage.ets(128:11)", "entry");
                    Image.width('100%');
                    Image.height('100%');
                    Image.backgroundColor("#ccaabb");
                }, Image);
            });
            TabContent.width('100%');
            TabContent.height('100%');
            TabContent.tabBar({ builder: () => {
                    this.tabGirl4.call(this);
                } });
            TabContent.debugLine("entry/src/main/ets/pages/TabsPage.ets(127:9)", "entry");
        }, TabContent);
        TabContent.pop();
        Tabs.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "TabsPage";
    }
}
registerNamedRoute(() => new TabsPage(undefined, {}), "", { bundleName: "com.xxd.jg", moduleName: "entry", pagePath: "pages/TabsPage", pageFullPath: "entry/src/main/ets/pages/TabsPage", integratedHsp: "false" });
