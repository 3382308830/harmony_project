if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface QRCodePage_Params {
}
class QRCodePage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: QRCodePage_Params) {
    }
    updateStateVars(params: QRCodePage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/QRCodePage.ets(6:5)", "entry");
            Column.height('100%');
            Column.width('100%');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            QRCode.create('https://baidu.com');
            QRCode.debugLine("entry/src/main/ets/pages/QRCodePage.ets(7:7)", "entry");
            QRCode.width(300);
            QRCode.height(300);
            QRCode.margin({ top: 50 });
            QRCode.color(Color.Black);
        }, QRCode);
        QRCode.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "QRCodePage";
    }
}
registerNamedRoute(() => new QRCodePage(undefined, {}), "", { bundleName: "com.xxd.jg", moduleName: "entry", pagePath: "pages/QRCodePage", pageFullPath: "entry/src/main/ets/pages/QRCodePage", integratedHsp: "false" });
