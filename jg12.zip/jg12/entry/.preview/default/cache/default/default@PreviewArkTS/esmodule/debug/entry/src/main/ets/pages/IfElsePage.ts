if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface IfElsePage_Params {
    showImage?: boolean;
}
class IfElsePage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__showImage = new ObservedPropertySimplePU(false, this, "showImage");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: IfElsePage_Params) {
        if (params.showImage !== undefined) {
            this.showImage = params.showImage;
        }
    }
    updateStateVars(params: IfElsePage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__showImage.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__showImage.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __showImage: ObservedPropertySimplePU<boolean>;
    get showImage() {
        return this.__showImage.get();
    }
    set showImage(newValue: boolean) {
        this.__showImage.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/IfElsePage.ets(7:5)", "entry");
            Column.height('100%');
            Column.width('100%');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.showImage) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Image.create({ "id": 16777233, "type": 20000, params: [], "bundleName": "com.xxd.jg", "moduleName": "entry" });
                        Image.debugLine("entry/src/main/ets/pages/IfElsePage.ets(9:9)", "entry");
                        Image.width('80%');
                        Image.height('70%');
                    }, Image);
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('图片正在加载...');
                        Text.debugLine("entry/src/main/ets/pages/IfElsePage.ets(13:9)", "entry");
                        Text.fontSize(40);
                        Text.fontWeight(500);
                        Text.textAlign(TextAlign.Center);
                        Text.width('80%');
                        Text.height('70%');
                    }, Text);
                    Text.pop();
                });
            }
        }, If);
        If.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel(this.showImage ? '图片已加载' : '图片加载中');
            Button.debugLine("entry/src/main/ets/pages/IfElsePage.ets(20:7)", "entry");
            Button.fontSize(40);
            Button.fontWeight(400);
            Button.type(ButtonType.Normal);
            Button.borderRadius(6);
            Button.backgroundColor(0xaabbcc);
            Button.width('80%');
            Button.margin({ top: 20 });
            Button.height(50);
            Button.onClick(() => {
                if (this.showImage == true) {
                    this.showImage = false;
                }
                else {
                    this.showImage = true;
                }
            });
        }, Button);
        Button.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "IfElsePage";
    }
}
registerNamedRoute(() => new IfElsePage(undefined, {}), "", { bundleName: "com.xxd.jg", moduleName: "entry", pagePath: "pages/IfElsePage", pageFullPath: "entry/src/main/ets/pages/IfElsePage", integratedHsp: "false" });
