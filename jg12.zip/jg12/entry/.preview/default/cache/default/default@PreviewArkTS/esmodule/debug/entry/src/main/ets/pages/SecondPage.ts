if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface SecondPage_Params {
    yonghu?: user;
}
import router from "@ohos:router";
class user {
    name: string = '';
    constructor(msg: string) {
        this.name = msg;
    }
}
class returnmsg {
    message: string = '';
    constructor(msg: string) {
        this.message = msg;
    }
}
class SecondPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__yonghu = new ObservedPropertyObjectPU(router.getParams() as user, this, "yonghu");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: SecondPage_Params) {
        if (params.yonghu !== undefined) {
            this.yonghu = params.yonghu;
        }
    }
    updateStateVars(params: SecondPage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__yonghu.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__yonghu.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __yonghu: ObservedPropertyObjectPU<user>;
    get yonghu() {
        return this.__yonghu.get();
    }
    set yonghu(newValue: user) {
        this.__yonghu.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            RelativeContainer.create();
            RelativeContainer.debugLine("entry/src/main/ets/pages/SecondPage.ets(23:5)", "entry");
            RelativeContainer.height('100%');
            RelativeContainer.width('100%');
        }, RelativeContainer);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('返回上一个页面');
            Button.debugLine("entry/src/main/ets/pages/SecondPage.ets(24:7)", "entry");
            Button.type(ButtonType.Normal);
            Button.borderRadius(6);
            Button.borderColor(0xff0000);
            Button.borderWidth(0);
            Button.backgroundColor(0x969696);
            Button.fontSize(30);
            Button.fontColor(0x000000);
            Button.fontWeight(FontWeight.Medium);
            Button.margin({ top: 30, left: 40 });
            Button.width('80%');
            Button.height(50);
            Button.onClick(() => {
                router.back({
                    url: "pages/FirstPage",
                    params: new returnmsg('登录成功')
                });
            });
        }, Button);
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 20 });
            Row.debugLine("entry/src/main/ets/pages/SecondPage.ets(44:7)", "entry");
            Row.width('80%');
            Row.height(50);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('用户名:');
            Text.debugLine("entry/src/main/ets/pages/SecondPage.ets(45:9)", "entry");
            Text.fontSize(30);
            Text.fontWeight(FontWeight.Medium);
            Text.margin({ top: 120, left: 40 });
            Text.height(50);
            Text.width('40%');
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.yonghu.name);
            Text.debugLine("entry/src/main/ets/pages/SecondPage.ets(52:9)", "entry");
            Text.fontSize(30);
            Text.fontWeight(FontWeight.Medium);
            Text.margin({ top: 120, left: 10 });
            Text.height(50);
            Text.width('40%');
        }, Text);
        Text.pop();
        Row.pop();
        RelativeContainer.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "SecondPage";
    }
}
registerNamedRoute(() => new SecondPage(undefined, {}), "", { bundleName: "com.xxd.jg", moduleName: "entry", pagePath: "pages/SecondPage", pageFullPath: "entry/src/main/ets/pages/SecondPage", integratedHsp: "false" });
