if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface PickerPage_Params {
}
class PickerPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: PickerPage_Params) {
    }
    updateStateVars(params: PickerPage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 20 });
            Column.debugLine("entry/src/main/ets/pages/PickerPage.ets(7:5)", "entry");
            Column.height('100%');
            Column.width('100%');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('时间选择器');
            Text.debugLine("entry/src/main/ets/pages/PickerPage.ets(8:7)", "entry");
            Text.fontSize(30);
            Text.fontWeight(500);
            Text.textAlign(TextAlign.Center);
            Text.size({ width: '100%', height: 50 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TimePicker.create({ selected: new Date() });
            TimePicker.debugLine("entry/src/main/ets/pages/PickerPage.ets(14:7)", "entry");
            TimePicker.width(300);
            TimePicker.height(200);
            TimePicker.borderWidth(10);
            TimePicker.borderColor(Color.Red);
            TimePicker.backgroundColor(Color.Pink);
            TimePicker.useMilitaryTime(true);
            TimePicker.onChange((date) => {
                console.log(`当前时间：${date.hour}:${date.minute}`);
            });
        }, TimePicker);
        TimePicker.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('日期选择器');
            Text.debugLine("entry/src/main/ets/pages/PickerPage.ets(25:7)", "entry");
            Text.fontSize(30);
            Text.fontWeight(500);
            Text.textAlign(TextAlign.Center);
            Text.size({ width: '100%', height: 50 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            DatePicker.create({
                start: new Date('2022-09-01'),
                end: new Date('2026-07-01'),
                selected: new Date()
            });
            DatePicker.debugLine("entry/src/main/ets/pages/PickerPage.ets(31:7)", "entry");
            DatePicker.lunar(false);
            DatePicker.width(300);
            DatePicker.height(200);
            DatePicker.borderWidth(10);
            DatePicker.borderColor(Color.Red);
            DatePicker.onChange((date) => {
                console.log(`当前日期：${date.year}-${date.month}-${date.day}`);
            });
        }, DatePicker);
        DatePicker.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "PickerPage";
    }
}
registerNamedRoute(() => new PickerPage(undefined, {}), "", { bundleName: "com.xxd.jg", moduleName: "entry", pagePath: "pages/PickerPage", pageFullPath: "entry/src/main/ets/pages/PickerPage", integratedHsp: "false" });
